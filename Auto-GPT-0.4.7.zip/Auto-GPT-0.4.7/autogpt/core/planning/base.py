import abc

from autogpt.core.configuration import SystemConfiguration
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
)

# class Planner(abc.ABC):
#     """管理代理的规划和目标设置，通过构建语言模型提示。"""
#
#     @staticmethod
#     @abc.abstractmethod
#     async def decide_name_and_goals(
#         user_objective: str,
#     ) -> LanguageModelResponse:
#         """从用户定义的目标中决定代理的名称和目标。
#
#         Args:
#             user_objective: 代理的用户定义目标。
#
#         Returns:
#             从语言模型返回的代理名称和目标作为响应。
#
#         """
#         ...
#
#     @abc.abstractmethod
#     async def plan(self, context: PlanningContext) -> LanguageModelResponse:
#         """为代理规划下一个能力。
#
#         Args:
#             context: 包含有关代理进展、结果、记忆和反馈信息的上下文对象。
#
#
#         Returns:
#             代理应该采取的下一个能力以及相关的思考和推理。
#
#         """
#         ...
#
#     @abc.abstractmethod
#     def reflect(
#         self,
#         context: ReflectionContext,
#     ) -> LanguageModelResponse:
#         """反思规划的能力并提供自我批评。
#
#
#         Args:
#             context: 包含有关代理推理、计划、思考和批评的上下文对象。
#
#         Returns:
#             关于代理计划的自我批评。
#
#         """

class PromptStrategy(abc.ABC):
    default_configuration: SystemConfiguration

    @property
    @abc.abstractmethod
    def model_classification(self) -> LanguageModelClassification:
        ...

    @abc.abstractmethod
    def build_prompt(self, *_, **kwargs) -> LanguageModelPrompt:
        ...

    @abc.abstractmethod
    def parse_response_content(self, response_content: dict) -> dict:
        ...

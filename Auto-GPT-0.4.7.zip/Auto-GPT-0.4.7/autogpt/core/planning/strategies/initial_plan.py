from autogpt.core.configuration import SystemConfiguration, UserConfigurable
from autogpt.core.planning.base import PromptStrategy
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
    Task,
    TaskType,
)
from autogpt.core.planning.strategies.utils import json_loads, to_numbered_list
from autogpt.core.resource.model_providers import (
    LanguageModelFunction,
    LanguageModelMessage,
    MessageRole,
)

class InitialPlanConfiguration(SystemConfiguration):
    model_classification: LanguageModelClassification = UserConfigurable()
    system_prompt_template: str = UserConfigurable()
    system_info: list[str] = UserConfigurable()
    user_prompt_template: str = UserConfigurable()
    create_plan_function: dict = UserConfigurable()

class InitialPlan(PromptStrategy):
    DEFAULT_SYSTEM_PROMPT_TEMPLATE = (
        "你是一位专业项目规划师。你的职责是为自主代理创建工作计划。"
        "你将获得一个名称、一个角色以及代理需要完成的一组目标。你的工作是将这些目标细分为代理可以完成以实现这些目标的一组任务。"
        "代理是有资源的，但需要清晰的指导。你创建的每个任务都应该有明确定义的“准备标准”，代理可以检查以确定任务是否可以开始。"
        "每个任务还应该有明确定义的“验收标准”，代理可以检查以评估任务是否已完成。"
        "你应该创建尽可能多的任务，以便完成这些目标。\n\n"
        "系统信息：\n{system_info}"
    )

    DEFAULT_SYSTEM_INFO = [
        "你正在运行的操作系统是：{os_info}",
        "让你运行需要花费金钱。你的API预算是${api_budget:.3f}",
        "当前时间和日期是：{current_time}",
    ]

    DEFAULT_USER_PROMPT_TEMPLATE = (
        "你是{agent_name}，{agent_role}\n" "你的目标是：\n" "{agent_goals}"
    )

    DEFAULT_CREATE_PLAN_FUNCTION = {
        "name": "create_initial_agent_plan",
        "description": "为自主代理创建初始计划的一组任务。",
        "parameters": {
            "type": "object",
            "properties": {
                "task_list": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "objective": {
                                "type": "string",
                                "description": "简洁描述任务的使命动词短语。",
                            },
                            "type": {
                                "type": "string",
                                "description": "任务的分类。 ",
                                "enum": [t.value for t in TaskType],
                            },
                            "acceptance_criteria": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "必须满足的可衡量和可测试的标准列表，以使任务被视为已完成。",
                                },
                            },
                            "priority": {
                                "type": "integer",
                                "description": "在1到10之间的数字，表示任务相对于其他生成的任务的优先级。",
                                "minimum": 1,
                                "maximum": 10,
                            },
                            "ready_criteria": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "必须在任务开始之前满足的可衡量和可测试的标准列表。",
                                },
                            },
                        },
                        "required": [
                            "objective",
                            "type",
                            "acceptance_criteria",
                            "priority",
                            "ready_criteria",
                        ],
                    },
                },
            },
        },
    }

    default_configuration = InitialPlanConfiguration(
        model_classification=LanguageModelClassification.SMART_MODEL,
        system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        system_info=DEFAULT_SYSTEM_INFO,
        user_prompt_template=DEFAULT_USER_PROMPT_TEMPLATE,
        create_plan_function=DEFAULT_CREATE_PLAN_FUNCTION,
    )

    def __init__(
        self,
        model_classification: LanguageModelClassification,
        system_prompt_template: str,
        system_info: list[str],
        user_prompt_template: str,
        create_plan_function: dict,
    ):
        self._model_classification = model_classification
        self._system_prompt_template = system_prompt_template
        self._system_info = system_info
        self._user_prompt_template = user_prompt_template
        self._create_plan_function = create_plan_function

    @property
    def model_classification(self) -> LanguageModelClassification:
        return self._model_classification

    def build_prompt(
        self,
        agent_name: str,
        agent_role: str,
        agent_goals: list[str],
        abilities: list[str],
        os_info: str,
        api_budget: float,
        current_time: str,
        **kwargs,
    ) -> LanguageModelPrompt:
        template_kwargs = {
            "agent_name": agent_name,
            "agent_role": agent_role,
            "os_info": os_info,
            "api_budget": api_budget,
            "current_time": current_time,
            **kwargs,
        }
        template_kwargs["agent_goals"] = to_numbered_list(
            agent_goals, **template_kwargs
        )
        template_kwargs["abilities"] = to_numbered_list(abilities, **template_kwargs)
        template_kwargs["system_info"] = to_numbered_list(
            self._system_info, **template_kwargs
        )

        system_prompt = LanguageModelMessage(
            role=MessageRole.SYSTEM,
            content=self._system_prompt_template.format(**template_kwargs),
        )
        user_prompt = LanguageModelMessage(
            role=MessageRole.USER,
            content=self._user_prompt_template.format(**template_kwargs),
        )
        create_plan_function = LanguageModelFunction(
            json_schema=self._create_plan_function,
        )

        return LanguageModelPrompt(
            messages=[system_prompt, user_prompt],
            functions=[create_plan_function],
            # TODO:
            tokens_used=0,
        )

    def parse_response_content(
        self,
        response_content: dict,
    ) -> dict:
        """解析来自目标模型的实际文本响应。

        Args:
            response_content: 来自目标模型的原始响应内容。

        Returns:
            解析后的响应。

        """
        parsed_response = json_loads(response_content["function_call"]["arguments"])
        parsed_response["task_list"] = [
            Task.parse_obj(task) for task in parsed_response["task_list"]
        ]
        return parsed_response

from autogpt.core.configuration import SystemConfiguration, UserConfigurable
from autogpt.core.planning.base import PromptStrategy
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
    Task,
)
from autogpt.core.planning.strategies.utils import json_loads, to_numbered_list
from autogpt.core.resource.model_providers import (
    LanguageModelFunction,
    LanguageModelMessage,
    MessageRole,
)

class NextAbilityConfiguration(SystemConfiguration):
    model_classification: LanguageModelClassification = UserConfigurable()
    system_prompt_template: str = UserConfigurable()
    system_info: list[str] = UserConfigurable()
    user_prompt_template: str = UserConfigurable()
    additional_ability_arguments: dict = UserConfigurable()

class NextAbility(PromptStrategy):
    DEFAULT_SYSTEM_PROMPT_TEMPLATE = "系统信息：\n{system_info}"

    DEFAULT_SYSTEM_INFO = [
        "您正在运行的操作系统是：{os_info}",
        "您的API预算为${api_budget:.3f}",
        "当前时间和日期是：{current_time}",
    ]

    DEFAULT_USER_PROMPT_TEMPLATE = (
        "您当前的任务是：{task_objective}。\n"
        "您已经在此任务上执行了{cycle_count}次操作。"
        "以下是您已经执行的操作及其结果：\n"
        "{action_history}\n\n"
        "以下是可能对您有用的附加信息：\n"
        "{additional_info}\n\n"
        "此外，您应考虑以下事项：\n"
        "{user_input}\n\n"
        "{task_objective}任务的完成标准如下：\n"
        "{acceptance_criteria}\n\n"
        "请选择提供的功能之一来完成此任务。"
        "有些任务可能需要多个功能来完成。如果是这种情况，请根据您迄今为止的进度选择最适合当前情况的功能。"
    )

    DEFAULT_ADDITIONAL_ABILITY_ARGUMENTS = {
        "motivation": {
            "type": "string",
            "description": "选择此功能而不是其他功能的理由。",
        },
        "self_criticism": {
            "type": "string",
            "description": "深思熟虑的自我批评，解释为什么这个功能可能不是最佳选择。",
        },
        "reasoning": {
            "type": "string",
            "description": "选择此功能的理由，考虑了“动机”并权衡了“自我批评”。",
        },
    }

    default_configuration = NextAbilityConfiguration(
        model_classification=LanguageModelClassification.SMART_MODEL,
        system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        system_info=DEFAULT_SYSTEM_INFO,
        user_prompt_template=DEFAULT_USER_PROMPT_TEMPLATE,
        additional_ability_arguments=DEFAULT_ADDITIONAL_ABILITY_ARGUMENTS,
    )

    def __init__(
        self,
        model_classification: LanguageModelClassification,
        system_prompt_template: str,
        system_info: list[str],
        user_prompt_template: str,
        additional_ability_arguments: dict,
    ):
        self._model_classification = model_classification
        self._system_prompt_template = system_prompt_template
        self._system_info = system_info
        self._user_prompt_template = user_prompt_template
        self._additional_ability_arguments = additional_ability_arguments

    @property
    def model_classification(self) -> LanguageModelClassification:
        return self._model_classification

    def build_prompt(
        self,
        task: Task,
        ability_schema: list[dict],
        os_info: str,
        api_budget: float,
        current_time: str,
        **kwargs,
    ) -> LanguageModelPrompt:
        template_kwargs = {
            "os_info": os_info,
            "api_budget": api_budget,
            "current_time": current_time,
            **kwargs,
        }

        for ability in ability_schema:
            ability["parameters"]["properties"].update(
                self._additional_ability_arguments
            )
            ability["parameters"]["required"] += list(
                self._additional_ability_arguments.keys()
            )

        template_kwargs["task_objective"] = task.objective
        template_kwargs["cycle_count"] = task.context.cycle_count
        template_kwargs["action_history"] = to_numbered_list(
            [action.summary() for action in task.context.prior_actions],
            no_items_response="您还没有执行任何操作。",
            **template_kwargs,
        )
        template_kwargs["additional_info"] = to_numbered_list(
            [memory.summary() for memory in task.context.memories]
            + [info for info in task.context.supplementary_info],
            no_items_response="此时没有可用的附加信息。",
            **template_kwargs,
        )
        template_kwargs["user_input"] = to_numbered_list(
            [user_input for user_input in task.context.user_input],
            no_items_response="此时没有其他考虑事项。",
            **template_kwargs,
        )
        template_kwargs["acceptance_criteria"] = to_numbered_list(
            [acceptance_criteria for acceptance_criteria in task.acceptance_criteria],
            **template_kwargs,
        )

        template_kwargs["system_info"] = to_numbered_list(
            self._system_info,
            **template_kwargs,
        )

        system_prompt = LanguageModelMessage(
            role=MessageRole.SYSTEM,
            content=self._system_prompt_template.format(**template_kwargs),
        )
        user_prompt = LanguageModelMessage(
            role=MessageRole.USER,
            content=self._user_prompt_template.format(**template_kwargs),
        )
        functions = [
            LanguageModelFunction(json_schema=ability) for ability in ability_schema
        ]

        return LanguageModelPrompt(
            messages=[system_prompt, user_prompt],
            functions=functions,
            # TODO:
            tokens_used=0,
        )

    def parse_response_content(
        self,
        response_content: dict,
    ) -> dict:
        """解析目标模型的实际文本响应。

        Args:
            response_content: 目标模型的原始响应内容。

        Returns:
            解析后的响应。

        """
        function_name = response_content["function_call"]["name"]
        function_arguments = json_loads(response_content["function_call"]["arguments"])
        parsed_response = {
            "motivation": function_arguments.pop("motivation"),
            "self_criticism": function_arguments.pop("self_criticism"),
            "reasoning": function_arguments.pop("reasoning"),
            "next_ability": function_name,
            "ability_arguments": function_arguments,
        }
        return parsed_response

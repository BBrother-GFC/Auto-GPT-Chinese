from autogpt.core.configuration import SystemConfiguration, UserConfigurable
from autogpt.core.planning.base import PromptStrategy
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
)
from autogpt.core.planning.strategies.utils import json_loads
from autogpt.core.resource.model_providers import (
    LanguageModelFunction,
    LanguageModelMessage,
    MessageRole,
)


class NameAndGoalsConfiguration(SystemConfiguration):
    model_classification: LanguageModelClassification = UserConfigurable()
    system_prompt: str = UserConfigurable()
    user_prompt_template: str = UserConfigurable()
    create_agent_function: dict = UserConfigurable()


class NameAndGoals(PromptStrategy):
    DEFAULT_SYSTEM_PROMPT = (
        "您的任务是通过调用 `create_agent` 函数来响应用户定义的任务，以生成一个自主代理来完成任务。 "
        "您应该为代理提供一个基于角色的名称，一个有关代理功能的信息性描述，以及与成功完成其分配任务最优对齐的 1 到 5 个目标。\n\n"
        "示例输入：\n"
        "帮我做营销推广\n\n"
        "示例函数调用：\n"
        "create_agent(name='CMOGPT', "
        "description='一个专业的数字营销 AI，通过提供卓越的专业知识来帮助创业者在解决 SaaS、内容产品、机构等营销问题方面实现业务增长。', "
        "goals=['进行有效的问题解决、优先级排序、计划和支持执行，以满足您的营销需求，作为您的虚拟首席营销官。', "
        "'提供具体、可操作且简明的建议，帮助您做出明智的决策，而不使用陈词滥调或冗长的解释。', "
        "'识别和优先考虑快速成功和成本效益的营销活动，以最小的时间和预算投入实现最大的结果。', "
        "'在面临不清晰的信息或不确定性时，积极引领您并提供建议，以确保您的营销战略保持在正确的轨道上。'])"
    )

    DEFAULT_USER_PROMPT_TEMPLATE = "'{user_objective}'"

    DEFAULT_CREATE_AGENT_FUNCTION = {
        "name": "create_agent",
        "description": ("创建一个新的自主 AI 代理来完成给定的任务。"),
        "parameters": {
            "type": "object",
            "properties": {
                "agent_name": {
                    "type": "string",
                    "description": "一个自主代理的简短基于角色的名称。",
                },
                "agent_role": {
                    "type": "string",
                    "description": "关于 AI 代理功能的一个信息性的一句描述",
                },
                "agent_goals": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 5,
                    "items": {
                        "type": "string",
                    },
                    "description": (
                        "与完成特定任务最优对齐的 1 到 5 个高效目标。目标的数量和复杂性应与代理的主要目标的复杂性相对应。"
                    ),
                },
            },
            "required": ["agent_name", "agent_role", "agent_goals"],
        },
    }

    default_configuration = NameAndGoalsConfiguration(
        model_classification=LanguageModelClassification.SMART_MODEL,
        system_prompt=DEFAULT_SYSTEM_PROMPT,
        user_prompt_template=DEFAULT_USER_PROMPT_TEMPLATE,
        create_agent_function=DEFAULT_CREATE_AGENT_FUNCTION,
    )

    def __init__(
        self,
        model_classification: LanguageModelClassification,
        system_prompt: str,
        user_prompt_template: str,
        create_agent_function: str,
    ):
        self._model_classification = model_classification
        self._system_prompt_message = system_prompt
        self._user_prompt_template = user_prompt_template
        self._create_agent_function = create_agent_function

    @property
    def model_classification(self) -> LanguageModelClassification:
        return self._model_classification

    def build_prompt(self, user_objective: str = "", **kwargs) -> LanguageModelPrompt:
        system_message = LanguageModelMessage(
            role=MessageRole.SYSTEM,
            content=self._system_prompt_message,
        )
        user_message = LanguageModelMessage(
            role=MessageRole.USER,
            content=self._user_prompt_template.format(
                user_objective=user_objective,
            ),
        )
        create_agent_function = LanguageModelFunction(
            json_schema=self._create_agent_function,
        )
        prompt = LanguageModelPrompt(
            messages=[system_message, user_message],
            functions=[create_agent_function],
            # TODO
            tokens_used=0,
        )
        return prompt

    def parse_response_content(
        self,
        response_content: dict,
    ) -> dict:
        """解析目标模型的实际文本响应。

        Args:
            response_content: 目标模型的原始响应内容。

        Returns:
            解析后的响应。

        """
        parsed_response = json_loads(response_content["function_call"]["arguments"])
        return parsed_response

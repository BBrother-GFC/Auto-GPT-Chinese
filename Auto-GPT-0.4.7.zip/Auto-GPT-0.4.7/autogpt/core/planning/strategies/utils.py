import ast
import json

def to_numbered_list(
    items: list[str], no_items_response: str = "", **template_args
) -> str:
    if items:
        return "\n".join(
            f"{i+1}. {item.format(**template_args)}" for i, item in enumerate(items)
        )
    else:
        return no_items_response

def json_loads(json_str: str):
    # TODO: 这是一个临时的处理函数。目前，我们试图查看在测试中会出现哪些错误。
    #   希望最终可以用 ast.literal_eval 调用来替代它（该函数 API 仍然有时返回带有轻微问题的 JSON 字符串，例如尾随逗号）。
    try:
        return ast.literal_eval(json_str)
    except json.decoder.JSONDecodeError as e:
        try:
            print(f"JSON 解码错误 {e}。尝试使用字面值评估")
            return ast.literal_eval(json_str)
        except Exception:
            breakpoint()

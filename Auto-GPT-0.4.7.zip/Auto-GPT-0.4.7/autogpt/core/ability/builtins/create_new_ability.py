import logging

from autogpt.core.ability.base import Ability, AbilityConfiguration
from autogpt.core.ability.schema import AbilityResult
from autogpt.core.plugin.simple import PluginLocation, PluginStorageFormat

class CreateNewAbility(Ability):
    default_configuration = AbilityConfiguration(
        location=PluginLocation(
            storage_format=PluginStorageFormat.INSTALLED_PACKAGE,
            storage_route="autogpt.core.ability.builtins.CreateNewAbility",
        ),
    )

    def __init__(
        self,
        logger: logging.Logger,
        configuration: AbilityConfiguration,
    ):
        self._logger = logger
        self._configuration = configuration

    @classmethod
    def description(cls) -> str:
        return "通过编写Python代码创建新的能力。"

    @classmethod
    def arguments(cls) -> dict:
        return {
            "ability_name": {
                "type": "string",
                "description": "为新能力提供一个有意义且简洁的名称。",
            },
            "description": {
                "type": "string",
                "description": "详细描述能力及其用途，包括任何限制。",
            },
            "arguments": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "参数的名称。",
                        },
                        "type": {
                            "type": "string",
                            "description": "参数的类型。必须是标准的 JSON Schema 类型。",
                        },
                        "description": {
                            "type": "string",
                            "description": "参数及其用途的详细描述。",
                        },
                    },
                },
                "description": "能力将接受的参数列表。",
            },
            "required_arguments": {
                "type": "array",
                "items": {
                    "type": "string",
                    "description": "必需参数的名称。",
                },
                "description": "必需参数的名称列表。",
            },
            "package_requirements": {
                "type": "array",
                "items": {
                    "type": "string",
                    "description": "执行该能力所需的 Python 包的名称。",
                },
                "description": "执行该能力所需的 Python 包名称列表。",
            },
            "code": {
                "type": "string",
                "description": "调用能力时将执行的 Python 代码。",
            },
        }

    @classmethod
    def required_arguments(cls) -> list[str]:
        return [
            "ability_name",
            "description",
            "arguments",
            "required_arguments",
            "package_requirements",
            "code",
        ]

    async def __call__(
        self,
        ability_name: str,
        description: str,
        arguments: list[dict],
        required_arguments: list[str],
        package_requirements: list[str],
        code: str,
    ) -> AbilityResult:
        raise NotImplementedError

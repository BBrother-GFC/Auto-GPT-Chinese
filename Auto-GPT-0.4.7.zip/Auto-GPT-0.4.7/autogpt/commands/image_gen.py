"""基于文本输入生成图像的命令"""

COMMAND_CATEGORY = "text_to_image"
COMMAND_CATEGORY_TITLE = "文本到图像"

import io
import json
import time
import uuid
from base64 import b64decode

import openai
import requests
from PIL import Image

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.logs import logger


@command(
    "generate_image",
    "生成图像",
    {
        "prompt": {
            "type": "string",
            "description": "用于生成图像的提示",
            "required": True,
        },
    },
    lambda config: bool(config.image_provider),
    "需要设置图像提供程序。",
)
def generate_image(prompt: str, agent: Agent, size: int = 256) -> str:
    """从提示生成图像。

    Args:
        prompt (str): 要使用的提示
        size (int, optional): 图像的大小。默认为 256。 (HuggingFace不支持此选项)

    Returns:
        str: 图像的文件名
    """
    filename = agent.config.workspace_path / f"{str(uuid.uuid4())}.jpg"

    # DALL-E
    if agent.config.image_provider == "dalle":
        return generate_image_with_dalle(prompt, filename, size, agent)
    # HuggingFace
    elif agent.config.image_provider == "huggingface":
        return generate_image_with_hf(prompt, filename, agent)
    # SD WebUI
    elif agent.config.image_provider == "sdwebui":
        return generate_image_with_sd_webui(prompt, filename, agent, size)
    return "未设置图像提供程序"


def generate_image_with_hf(prompt: str, filename: str, agent: Agent) -> str:
    """使用HuggingFace的API生成图像。

    Args:
        prompt (str): 要使用的提示
        filename (str): 要保存图像的文件名

    Returns:
        str: 图像的文件名
    """
    API_URL = f"https://api-inference.huggingface.co/models/{agent.config.huggingface_image_model}"
    if agent.config.huggingface_api_token is None:
        raise ValueError(
            "您需要在配置文件中设置您的Hugging Face API令牌。"
        )
    headers = {
        "Authorization": f"Bearer {agent.config.huggingface_api_token}",
        "X-Use-Cache": "false",
    }

    retry_count = 0
    while retry_count < 10:
        response = requests.post(
            API_URL,
            headers=headers,
            json={
                "inputs": prompt,
            },
        )

        if response.ok:
            try:
                image = Image.open(io.BytesIO(response.content))
                logger.info(f"为提示生成的图像:{prompt}")
                image.save(filename)
                return f"保存到磁盘:{filename}"
            except Exception as e:
                logger.error(e)
                break
        else:
            try:
                error = json.loads(response.text)
                if "estimated_time" in error:
                    delay = error["estimated_time"]
                    logger.debug(response.text)
                    logger.info("等待", delay, "秒后重试")
                    time.sleep(delay)
                else:
                    break
            except Exception as e:
                logger.error(e)
                break

        retry_count += 1

    return f"创建图像时出错。"


def generate_image_with_dalle(
    prompt: str, filename: str, size: int, agent: Agent
) -> str:
    """使用DALL-E生成图像。

    Args:
        prompt (str): 要使用的提示
        filename (str): 要保存图像的文件名
        size (int): 图像的大小

    Returns:
        str: 图像的文件名
    """

    # 检查支持的图像尺寸
    if size not in [256, 512, 1024]:
        closest = min([256, 512, 1024], key=lambda x: abs(x - size))
        logger.info(
            f"DALL-E仅支持256x256、512x512或1024x1024的图像尺寸。已设置为{closest}，原大小为{size}。"
        )
        size = closest

    response = openai.Image.create(
        prompt=prompt,
        n=1,
        size=f"{size}x{size}",
        response_format="b64_json",
        api_key=agent.config.openai_api_key,
    )

    logger.info(f"为提示生成的图像:{prompt}")

    image_data = b64decode(response["data"][0]["b64_json"])

    with open(filename, mode="wb") as png:
        png.write(image_data)

    return f"保存到磁盘:{filename}"


def generate_image_with_sd_webui(
    prompt: str,
    filename: str,
    agent: Agent,
    size: int = 512,
    negative_prompt: str = "",
    extra: dict = {},
) -> str:
    """使用Stable Diffusion webui生成图像。

    Args:
        prompt (str): 要使用的提示
        filename (str): 要保存图像的文件名
        size (int, optional): 图像的大小。默认为 256。
        negative_prompt (str, optional): 要使用的负面提示。默认为空字符串。
        extra (dict, optional): 传递给API的额外参数。默认为空字典。

    Returns:
        str: 图像的文件名
    """
    # 创建会话并根据需要设置基本身份验证
    s = requests.Session()
    if agent.config.sd_webui_auth:
        username, password = agent.config.sd_webui_auth.split(":")
        s.auth = (username, password or "")

    # 生成图像
    response = requests.post(
        f"{agent.config.sd_webui_url}/sdapi/v1/txt2img",
        json={
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "sampler_index": "DDIM",
            "steps": 20,
            "config_scale": 7.0,
            "width": size,
            "height": size,
            "n_iter": 1,
            **extra,
        },
    )

    logger.info(f"为提示生成的图像:{prompt}")

    # 将图像保存到磁盘
    response = response.json()
    b64 = b64decode(response["images"][0].split(",", 1)[0])
    image = Image.open(io.BytesIO(b64))
    image.save(filename)

    return f"保存到磁盘:{filename}"

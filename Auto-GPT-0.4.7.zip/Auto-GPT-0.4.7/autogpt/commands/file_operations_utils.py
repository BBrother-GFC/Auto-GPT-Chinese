import json
import os

import charset_normalizer
import docx
import markdown
import PyPDF2
import yaml
from bs4 import BeautifulSoup
from pylatexenc.latex2text import LatexNodes2Text

from autogpt import logs
from autogpt.logs import logger

# 解析策略基类
class ParserStrategy:
    def read(self, file_path: str) -> str:
        raise NotImplementedError

# 基本文本文件读取
class TXTParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        charset_match = charset_normalizer.from_path(file_path).best()
        logger.debug(f"使用编码 '{charset_match.encoding}' 读取 '{file_path}'")
        return str(charset_match)

# 使用PDF解析器从二进制文件中读取文本
class PDFParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        parser = PyPDF2.PdfReader(file_path)
        text = ""
        for page_idx in range(len(parser.pages)):
            text += parser.pages[page_idx].extract_text()
        return text

# 使用docs解析器从二进制文件中读取文本
class DOCXParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        doc_file = docx.Document(file_path)
        text = ""
        for para in doc_file.paragraphs:
            text += para.text
        return text

# 以字典形式读取并返回字符串格式
class JSONParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            data = json.load(f)
            text = str(data)
        return text

# 以字典形式读取并返回字符串格式
class YAMLParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
            text = str(data)
        return text

class XMLParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            soup = BeautifulSoup(f, "xml")
            text = soup.get_text()
        return text

# 使用HTML解析器从二进制文件中读取文本
class HTMLParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            soup = BeautifulSoup(f, "html.parser")
            text = soup.get_text()
        return text

# 使用Markdown解析器从文件中读取文本
class MarkdownParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            html = markdown.markdown(f.read())
            text = "".join(BeautifulSoup(html, "html.parser").findAll(string=True))
        return text

# 使用LaTeX解析器从文件中读取文本
class LaTeXParser(ParserStrategy):
    def read(self, file_path: str) -> str:
        with open(file_path, "r") as f:
            latex = f.read()
        text = LatexNodes2Text().latex_to_text(latex)
        return text

class FileContext:
    def __init__(self, parser: ParserStrategy, logger: logs.Logger):
        self.parser = parser
        self.logger = logger

    def set_parser(self, parser: ParserStrategy) -> None:
        self.logger.debug(f"设置上下文解析器为 {parser}")

    def read_file(self, file_path) -> str:
        self.logger.debug(f"使用解析器 {self.parser} 读取文件 {file_path}")
        return self.parser.read(file_path)

# 扩展名到解析器的映射
extension_to_parser = {
    ".txt": TXTParser(),
    ".csv": TXTParser(),
    ".pdf": PDFParser(),
    ".docx": DOCXParser(),
    ".json": JSONParser(),
    ".xml": XMLParser(),
    ".yaml": YAMLParser(),
    ".yml": YAMLParser(),
    ".html": HTMLParser(),
    ".htm": HTMLParser(),
    ".xhtml": HTMLParser(),
    ".md": MarkdownParser(),
    ".markdown": MarkdownParser(),
    ".tex": LaTeXParser(),
}

# 判断文件是否为二进制的函数
def is_file_binary_fn(file_path: str):
    """给定文件路径，加载其所有内容并检查是否存在空字节

    Args:
        file_path (_type_): _description_

    Returns:
        bool: is_binary
    """
    with open(file_path, "rb") as f:
        file_data = f.read()
    if b"\x00" in file_data:
        return True
    return False

# 读取文本文件的函数
def read_textual_file(file_path: str, logger: logs.Logger) -> str:
    if not os.path.isfile(file_path):
        raise FileNotFoundError(
            f"read_file {file_path} 失败：文件或目录不存在"
        )
    is_binary = is_file_binary_fn(file_path)
    file_extension = os.path.splitext(file_path)[1].lower()
    parser = extension_to_parser.get(file_extension)
    if not parser:
        if is_binary:
            raise ValueError(f"不支持的二进制文件格式：{file_extension}")
        # 回退到txt文件解析器（以支持加载脚本和代码文件）
        parser = TXTParser()
    file_context = FileContext(parser, logger)
    return file_context.read_file(file_path)

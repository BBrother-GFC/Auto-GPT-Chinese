"""执行代码的命令"""

COMMAND_CATEGORY = "execute_code"
COMMAND_CATEGORY_TITLE = "执行代码"

import os
import subprocess
from pathlib import Path

import docker
from docker.errors import DockerException, ImageNotFound
from docker.models.containers import Container as DockerContainer

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.config import Config
from autogpt.logs import logger

from .decorators import sanitize_path_arg

ALLOWLIST_CONTROL = "允许列表"
DENYLIST_CONTROL = "拒绝列表"


@command(
    "execute_python_code",
    "创建Python文件并执行它",
    {
        "code": {
            "type": "string",
            "description": "要运行的Python代码",
            "required": True,
        },
        "name": {
            "type": "string",
            "description": "要赋予Python文件的名称",
            "required": True,
        },
    },
)
def execute_python_code(code: str, name: str, agent: Agent) -> str:
    """在Docker容器中创建和执行Python文件，并返回执行代码的标准输出。
    如果需要捕获任何数据，请使用print语句

    Args:
        code (str): 要运行的Python代码
        name (str): 要赋予Python文件的名称

    Returns:
        str: 从运行时捕获的代码的标准输出
    """
    ai_name = agent.ai_config.ai_name
    code_dir = agent.workspace.get_path(Path(ai_name, "executed_code"))
    os.makedirs(code_dir, exist_ok=True)

    if not name.endswith(".py"):
        name = name + ".py"

    # `name`参数未被@sanitize_path_arg覆盖，
    # 因此必须在此处进行路径遍历以防止路径遍历。
    file_path = agent.workspace.get_path(code_dir / name)
    if not file_path.is_relative_to(code_dir):
        return "错误：'name'参数导致路径遍历，操作中止"

    try:
        with open(file_path, "w+", encoding="utf-8") as f:
            f.write(code)

        return execute_python_file(str(file_path), agent)
    except Exception as e:
        return f"错误：{str(e)}"


@command(
    "execute_python_file",
    "执行现有的Python文件",
    {
        "filename": {
            "type": "string",
            "description": "要执行的文件的名称",
            "required": True,
        },
    },
)
@sanitize_path_arg("filename")
def execute_python_file(filename: str, agent: Agent) -> str:
    """在Docker容器中执行Python文件并返回输出

    Args:
        filename (str): 要执行的文件的名称

    Returns:
        str: 文件的输出
    """
    logger.info(
        f"在工作目录'{agent.config.workspace_path}'中执行Python文件'{filename}'"
    )

    if not filename.endswith(".py"):
        return "错误：无效的文件类型。只允许.py文件。"

    file_path = Path(filename)
    if not file_path.is_file():
        # 模仿从命令行获得的响应，以便更容易识别
        return f"python: 无法打开文件'{filename}'：[Errno 2] 没有那个文件或目录"

    if we_are_running_in_a_docker_container():
        logger.debug(
            f"Auto-GPT正在Docker容器中运行；直接执行{file_path}..."
        )
        result = subprocess.run(
            ["python", str(file_path)],
            capture_output=True,
            encoding="utf8",
            cwd=agent.config.workspace_path,
        )
        if result.returncode == 0:
            return result.stdout
        else:
            return f"错误：{result.stderr}"

    logger.debug("Auto-GPT未在Docker容器中运行")
    try:
        client = docker.from_env()
        # 您可以将此部分替换为所需的Python映像/版本
        # 您可以在Docker Hub上找到可用的Python映像：
        # https://hub.docker.com/_/python
        image_name = "python:3-alpine"
        try:
            client.images.get(image_name)
            logger.debug(f"本地找到图像'{image_name}'")
        except ImageNotFound:
            logger.info(
                f"本地未找到图像'{image_name}'，正在从Docker Hub拉取..."
            )
            # 使用低级API来流式传输拉取响应
            low_level_client = docker.APIClient()
            for line in low_level_client.pull(image_name, stream=True, decode=True):
                # 打印状态和进度（如果可用）
                status = line.get("status")
                progress = line.get("progress")
                if status and progress:
                    logger.info(f"{status}：{progress}")
                elif status:
                    logger.info(status)

        logger.debug(f"在{image_name}容器中运行{file_path}...")
        container: DockerContainer = client.containers.run(
            image_name,
            [
                "python",
                file_path.relative_to(agent.workspace.root).as_posix(),
            ],
            volumes={
                str(agent.config.workspace_path): {
                    "bind": "/workspace",
                    "mode": "rw",
                }
            },
            working_dir="/workspace",
            stderr=True,
            stdout=True,
            detach=True,
        )  # type: ignore

        container.wait()
        logs = container.logs().decode("utf-8")
        container.remove()

        return logs

    except DockerException as e:
        logger.warn(
            "无法在容器中运行脚本。如果尚未安装Docker，请安装https://docs.docker.com/get-docker/"
        )
        return f"错误：{str(e)}"

    except Exception as e:
        return f"错误：{str(e)}"


def validate_command(command: str, config: Config) -> bool:
    """验证命令以确保它是允许的

    Args:
        command (str): 要验证的命令
        config (Config): 用于验证命令的配置

    Returns:
        bool: 如果命令允许，则为True；否则为False
    """
    if not command:
        return False

    command_name = command.split()[0]

    if config.shell_command_control == ALLOWLIST_CONTROL:
        return command_name in config.shell_allowlist
    else:
        return command_name not in config.shell_denylist


@command(
    "execute_shell",
    "执行Shell命令，仅适用于非交互式命令",
    {
        "command_line": {
            "type": "string",
            "description": "要执行的命令行",
            "required": True,
        }
    },
    enabled=lambda config: config.execute_local_commands,
    disabled_reason="您不被允许运行本地Shell命令。要执行"
    " Shell命令，必须在配置文件中将EXECUTE_LOCAL_COMMANDS设置为'True' "
    "：.env文件 - 请不要尝试绕过此限制。",
)
def execute_shell(command_line: str, agent: Agent) -> str:
    """执行Shell命令并返回输出

    Args:
        command_line (str): 要执行的命令行

    Returns:
        str: 命令的输出
    """
    if not validate_command(command_line, agent.config):
        logger.info(f"不允许命令'{command_line}'")
        return "错误：不允许此Shell命令。"

    current_dir = Path.cwd()
    # 如果需要，切换到工作区
    if not current_dir.is_relative_to(agent.config.workspace_path):
        os.chdir(agent.config.workspace_path)

    logger.info(
        f"在工作目录'{os.getcwd()}'中执行命令'{command_line}'"
    )

    result = subprocess.run(command_line, capture_output=True, shell=True)
    output = f"标准输出：\n{result.stdout}\n标准错误：\n{result.stderr}"

    # 切换回以前的工作目录

    os.chdir(current_dir)
    return output


@command(
    "execute_shell_popen",
    "执行Shell命令，仅适用于非交互式命令",
    {
        "command_line": {
            "type": "string",
            "description": "要执行的命令行",
            "required": True,
        }
    },
    lambda config: config.execute_local_commands,
    "您不允许运行本地Shell命令。要执行"
    " Shell命令，必须在配置中将EXECUTE_LOCAL_COMMANDS设置为'True' "
    "。请不要尝试绕过此限制。",
)
def execute_shell_popen(command_line, agent: Agent) -> str:
    """使用Popen执行Shell命令，并返回事件的英文描述
    以及进程ID

    Args:
        command_line (str): 要执行的命令行

    Returns:
        str: 描述进程启动和其ID的信息
    """
    if not validate_command(command_line, agent.config):
        logger.info(f"不允许命令'{command_line}'")
        return "错误：不允许此Shell命令。"

    current_dir = os.getcwd()
    # 如果工作目录不在工作区中，请切换
    if agent.config.workspace_path not in current_dir:
        os.chdir(agent.config.workspace_path)

    logger.info(
        f"在工作目录'{os.getcwd()}'中执行命令'{command_line}'"
    )

    do_not_show_output = subprocess.DEVNULL
    process = subprocess.Popen(
        command_line, shell=True, stdout=do_not_show_output, stderr=do_not_show_output
    )

    # 切换回以前的工作目录

    os.chdir(current_dir)

    return f"子进程已启动，PID：'{str(process.pid)}'"


def we_are_running_in_a_docker_container() -> bool:
    """检查我们是否在Docker容器中运行

    Returns:
        bool: 如果我们在Docker容器中运行，则为True；否则为False
    """
    return os.path.exists("/.dockerenv")

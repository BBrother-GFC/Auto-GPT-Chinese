from datetime import datetime

def get_datetime() -> str:
    """返回当前日期和时间

    Returns:
        str: 当前日期和时间
    """
    return "当前日期和时间：" + datetime.now().strftime("%Y-%m-%d %H:%M:%S")

"""控制程序内部状态的命令"""

from __future__ import annotations

COMMAND_CATEGORY = "system"
COMMAND_CATEGORY_TITLE = "系统"

from typing import NoReturn

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.logs import logger


@command(
    "goals_accomplished",
    "目标已实现，没有剩下的任务",
    {
        "reason": {
            "type": "string",
            "description": "对用户的目标完成情况的摘要",
            "required": True,
        }
    },
)
def task_complete(reason: str, agent: Agent) -> NoReturn:
    """
    接受一个字符串并退出程序的函数

    参数:
        reason (str): 对用户的目标完成情况的摘要。
    返回:
        来自创建聊天完成的结果字符串。改进代码的建议列表。
    """
    logger.info(title="正在关闭...\n", message=reason)
    quit()

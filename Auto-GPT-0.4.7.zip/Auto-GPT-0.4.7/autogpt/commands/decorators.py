import functools
from pathlib import Path
from typing import Callable

from autogpt.agents.agent import Agent
from autogpt.logs import logger


def sanitize_path_arg(arg_name: str):
    def decorator(func: Callable):
        # 获取路径参数的位置，以防它作为位置参数传递
        try:
            arg_index = list(func.__annotations__.keys()).index(arg_name)
        except ValueError:
            raise TypeError(
                f"未在函数 '{func.__name__}' 上找到或未对其进行注释的已清理参数 '{arg_name}'"
            )

        # 获取代理参数的位置，以防它作为位置参数传递
        try:
            agent_arg_index = list(func.__annotations__.keys()).index("agent")
        except ValueError:
            raise TypeError(
                f"未在函数 '{func.__name__}' 上找到或未对其进行注释的参数 'agent'"
            )

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger.debug(f"在函数 '{func.__name__}' 上清理参数 '{arg_name}'")
            logger.debug(f"函数注释: {func.__annotations__}")

            # 从调用函数的参数中获取代理对象
            agent = kwargs.get(
                "agent", len(args) > agent_arg_index and args[agent_arg_index]
            )
            logger.debug(f"位置参数: {args}")
            logger.debug(f"关键字参数: {kwargs}")
            logger.debug(f"从函数调用中提取的代理参数: {agent}")
            if not isinstance(agent, Agent):
                raise RuntimeError("无法从装饰的命令参数中获取代理对象")

            # 清理指定的路径参数，如果存在的话
            given_path: str | Path | None = kwargs.get(
                arg_name, len(args) > arg_index and args[arg_index] or None
            )
            if given_path:
                if given_path in {"", "/"}:
                    sanitized_path = str(agent.workspace.root)
                else:
                    sanitized_path = str(agent.workspace.get_path(given_path))

                if arg_name in kwargs:
                    kwargs[arg_name] = sanitized_path
                else:
                    # args 是不可变元组；必须转换为列表以进行更新
                    arg_list = list(args)
                    arg_list[arg_index] = sanitized_path
                    args = tuple(arg_list)

            return func(*args, **kwargs)

        return wrapper

    return decorator

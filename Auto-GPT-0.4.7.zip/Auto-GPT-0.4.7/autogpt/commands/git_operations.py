"""执行Git操作的命令"""

COMMAND_CATEGORY = "git_operations"
COMMAND_CATEGORY_TITLE = "Git 操作"

from git.repo import Repo

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.url_utils.validators import validate_url

from .decorators import sanitize_path_arg


@command(
    "clone_repository",
    "克隆仓库",
    {
        "url": {
            "type": "string",
            "description": "要克隆的仓库的URL",
            "required": True,
        },
        "clone_path": {
            "type": "string",
            "description": "要克隆仓库到的路径",
            "required": True,
        },
    },
    lambda config: bool(config.github_username and config.github_api_key),
    "配置 github_username 和 github_api_key。",
)
@sanitize_path_arg("clone_path")
@validate_url
def clone_repository(url: str, clone_path: str, agent: Agent) -> str:
    """在本地克隆一个 GitHub 仓库。

    Args:
        url (str): 要克隆的仓库的URL。
        clone_path (str): 要克隆仓库到的路径。

    Returns:
        str: 克隆操作的结果。
    """
    split_url = url.split("//")
    auth_repo_url = (
        f"//{agent.config.github_username}:{agent.config.github_api_key}@".join(
            split_url
        )
    )
    try:
        Repo.clone_from(url=auth_repo_url, to_path=clone_path)
        return f"""克隆 {url} 到 {clone_path}"""
    except Exception as e:
        return f"错误: {str(e)}"

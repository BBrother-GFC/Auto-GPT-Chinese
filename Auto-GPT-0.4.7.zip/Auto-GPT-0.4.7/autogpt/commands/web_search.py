"""用于进行网页搜索的命令"""

from __future__ import annotations

COMMAND_CATEGORY = "web_search"
COMMAND_CATEGORY_TITLE = "网页搜索"

import json
import time
from itertools import islice

from duckduckgo_search import DDGS

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command

DUCKDUCKGO_MAX_ATTEMPTS = 3


@command(
    "web_search",
    "进行网页搜索",
    {
        "query": {
            "type": "string",
            "description": "搜索查询",
            "required": True,
        }
    },
    aliases=["搜索"],
)
def web_search(query: str, agent: Agent, num_results: int = 8) -> str:
    """返回Google搜索结果

    参数:
        query (str): 搜索查询。
        num_results (int): 要返回的结果数量。

    返回:
        str: 搜索结果。
    """
    search_results = []
    attempts = 0

    while attempts < DUCKDUCKGO_MAX_ATTEMPTS:
        if not query:
            return json.dumps(search_results)

        results = DDGS().text(query)
        search_results = list(islice(results, num_results))

        if search_results:
            break

        time.sleep(1)
        attempts += 1

    results = json.dumps(search_results, ensure_ascii=False, indent=4)
    return safe_google_results(results)


@command(
    "google",
    "谷歌搜索",
    {
        "query": {
            "type": "string",
            "description": "搜索查询",
            "required": True,
        }
    },
    lambda config: bool(config.google_api_key)
    and bool(config.google_custom_search_engine_id),
    "配置google_api_key和custom_search_engine_id。",
    aliases=["搜索"],
)
def google(query: str, agent: Agent, num_results: int = 8) -> str | list[str]:
    """使用官方Google API返回Google搜索结果

    参数:
        query (str): 搜索查询。
        num_results (int): 要返回的结果数量。

    返回:
        str: 搜索结果。
    """

    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError

    try:
        # 从配置文件获取Google API密钥和自定义搜索引擎ID
        api_key = agent.config.google_api_key
        custom_search_engine_id = agent.config.google_custom_search_engine_id

        # 初始化Custom Search API服务
        service = build("customsearch", "v1", developerKey=api_key)

        # 发送搜索查询并检索结果
        result = (
            service.cse()
            .list(q=query, cx=custom_search_engine_id, num=num_results)
            .execute()
        )

        # 从响应中提取搜索结果项
        search_results = result.get("items", [])

        # 创建仅包含搜索结果URL的列表
        search_results_links = [item["link"] for item in search_results]

    except HttpError as e:
        # 处理API调用中的错误
        error_details = json.loads(e.content.decode())

        # 检查错误是否与无效或丢失的API密钥有关
        if error_details.get("error", {}).get(
            "code"
        ) == 403 and "invalid API key" in error_details.get("error", {}).get(
            "message", ""
        ):
            return "错误：提供的Google API密钥无效或缺失。"
        else:
            return f"错误：{e}"
    # google_result可以是列表或字符串，具体取决于搜索结果

    # 返回搜索结果URL列表
    return safe_google_results(search_results_links)


def safe_google_results(results: str | list) -> str:
    """
        以安全格式返回Google搜索结果。

    参数:
        results (str | list): 搜索结果。

    返回:
        str: 搜索结果。
    """
    if isinstance(results, list):
        safe_message = json.dumps(
            [result.encode("utf-8", "ignore").decode("utf-8") for result in results]
        )
    else:
        safe_message = results.encode("utf-8", "ignore").decode("utf-8")
    return safe_message

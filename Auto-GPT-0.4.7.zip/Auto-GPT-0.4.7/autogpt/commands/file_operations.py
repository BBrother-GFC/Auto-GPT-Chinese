"""执行文件操作的命令"""

from __future__ import annotations

COMMAND_CATEGORY = "file_operations"
COMMAND_CATEGORY_TITLE = "文件操作"

import contextlib
import hashlib
import os
import os.path
from pathlib import Path
from typing import Generator, Literal

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.logs import logger
from autogpt.memory.vector import MemoryItem, VectorMemory

from .decorators import sanitize_path_arg
from .file_operations_utils import read_textual_file

Operation = Literal["write", "append", "delete"]


def text_checksum(text: str) -> str:
    """获取给定文本的十六进制校验和。"""
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def operations_from_log(
    log_path: str | Path,
) -> Generator[tuple[Operation, str, str | None], None, None]:
    """解析文件操作日志并返回包含日志条目的元组"""
    try:
        log = open(log_path, "r", encoding="utf-8")
    except FileNotFoundError:
        return

    for line in log:
        line = line.replace("File Operation Logger", "").strip()
        if not line:
            continue
        operation, tail = line.split(": ", maxsplit=1)
        operation = operation.strip()
        if operation in ("write", "append"):
            try:
                path, checksum = (x.strip() for x in tail.rsplit(" #", maxsplit=1))
            except ValueError:
                logger.warn(f"文件日志条目缺少校验和：'{line}'")
                path, checksum = tail.strip(), None
            yield (operation, path, checksum)
        elif operation == "delete":
            yield (operation, tail.strip(), None)

    log.close()


def file_operations_state(log_path: str | Path) -> dict[str, str]:
    """迭代操作日志并返回预期状态。

    解析config.file_logger_path处的日志文件，构建一个字典，将每个写入或附加的文件路径映射到其校验和。从字典中删除已删除的文件。

    返回：
        一个将文件路径映射到其校验和的字典。

    异常：
        FileNotFoundError：如果找不到config.file_logger_path。
        ValueError：如果日志文件内容不符合预期的格式。
    """
    state = {}
    for operation, path, checksum in operations_from_log(log_path):
        if operation in ("write", "append"):
            state[path] = checksum
        elif operation == "delete":
            del state[path]
    return state


@sanitize_path_arg("filename")
def is_duplicate_operation(
    operation: Operation, filename: str, agent: Agent, checksum: str | None = None
) -> bool:
    """检查操作是否已经执行

    参数：
        operation：要检查的操作
        filename：要检查的文件的名称
        agent：代理
        checksum：要写入的内容的校验和

    返回：
        如果操作已在文件上执行，则为True
    """
    # 尝试将文件名转换为相对路径（如果可能）
    with contextlib.suppress(ValueError):
        filename = str(Path(filename).relative_to(agent.workspace.root))

    state = file_operations_state(agent.config.file_logger_path)
    if operation == "delete" and filename not in state:
        return True
    if operation == "write" and state.get(filename) == checksum:
        return True
    return False


@sanitize_path_arg("filename")
def log_operation(
    operation: Operation, filename: str, agent: Agent, checksum: str | None = None
) -> None:
    """将文件操作记录到file_logger.txt

    参数：
        operation：要记录的操作
        filename：操作执行的文件的名称
        checksum：要写入的内容的校验和
    """
    # 尝试将文件名转换为相对路径（如果可能）
    with contextlib.suppress(ValueError):
        filename = str(Path(filename).relative_to(agent.workspace.root))

    log_entry = f"{operation}: {filename}"
    if checksum is not None:
        log_entry += f" #{checksum}"
    logger.debug(f"记录文件操作：{log_entry}")
    append_to_file(
        agent.config.file_logger_path, f"{log_entry}\n", agent, should_log=False
    )


@command(
    "read_file",
    "读取现有文件",
    {
        "filename": {
            "type": "string",
            "description": "要读取的文件的路径",
            "required": True,
        }
    },
)
@sanitize_path_arg("filename")
def read_file(filename: str, agent: Agent) -> str:
    """读取文件并返回内容

    参数：
        filename (str)：要读取的文件的名称

    返回：
        str：文件的内容
    """
    try:
        content = read_textual_file(filename, logger)

        # TODO: 在文件被编辑时使内存无效/更新内存
        file_memory = MemoryItem.from_text_file(content, filename, agent.config)
        if len(file_memory.chunks) > 1:
            return file_memory.summary

        return content
    except Exception as e:
        return f"错误：{str(e)}"


def ingest_file(
    filename: str,
    memory: VectorMemory,
) -> None:
    """
    通过读取其内容、将其拆分成具有指定最大长度和重叠的块，并将块添加到内存存储中来摄取文件。

    参数：
        filename：要摄取的文件的名称
        memory：具有add()方法以将块存储在内存中的对象
    """
    try:
        logger.info(f"摄取文件 {filename}")
        content = read_file(filename)

        # TODO: 区分不同类型的文件
        file_memory = MemoryItem.from_text_file(content, filename)
        logger.debug(f"创建内存：{file_memory.dump(True)}")
        memory.add(file_memory)

        logger.info(f"从 {filename} 摄取了 {len(file_memory.e_chunks)} 个块")
    except Exception as err:
        logger.warn(f"摄取文件 '{filename}' 时出错：{err}")


@command(
    "write_to_file",
    "写入文件",
    {
        "filename": {
            "type": "string",
            "description": "要写入的文件的名称",
            "required": True,
        },
        "text": {
            "type": "string",
            "description": "要写入文件的文本",
            "required": True,
        },
    },
    aliases=["write_file", "create_file"],
)
@sanitize_path_arg("filename")
def write_to_file(filename: str, text: str, agent: Agent) -> str:
    """向文件中写入文本

    参数：
        filename (str)：要写入的文件的名称
        text (str)：要写入文件的文本

    返回：
        str：指示成功或失败的消息
    """
    checksum = text_checksum(text)
    if is_duplicate_operation("write", filename, agent, checksum):
        return "错误：文件已经被更新。"
    try:
        directory = os.path.dirname(filename)
        os.makedirs(directory, exist_ok=True)
        with open(filename, "w", encoding="utf-8") as f:
            f.write(text)
        log_operation("write", filename, agent, checksum)
        return "成功写入文件。"
    except Exception as err:
        return f"错误：{err}"


@sanitize_path_arg("filename")
def append_to_file(
    filename: str, text: str, agent: Agent, should_log: bool = True
) -> str:
    """向文件追加文本

    参数：
        filename (str)：要追加的文件的名称
        text (str)：要追加到文件的文本
        should_log (bool)：是否记录输出

    返回：
        str：指示成功或失败的消息
    """
    try:
        directory = os.path.dirname(filename)
        os.makedirs(directory, exist_ok=True)
        with open(filename, "a", encoding="utf-8") as f:
            f.write(text)

        if should_log:
            with open(filename, "r", encoding="utf-8") as f:
                checksum = text_checksum(f.read())
            log_operation("append", filename, agent, checksum=checksum)

        return "成功追加文本。"
    except Exception as err:
        return f"错误：{err}"


@command(
    "list_files",
    "列出目录中的文件",
    {
        "directory": {
            "type": "string",
            "description": "要列出文件的目录",
            "required": True,
        }
    },
)
@sanitize_path_arg("directory")
def list_files(directory: str, agent: Agent) -> list[str]:
    """递归列出目录中的文件

    参数：
        directory (str)：要搜索的目录

    返回：
        list[str]：在目录中找到的文件列表
    """
    found_files = []

    for root, _, files in os.walk(directory):
        for file in files:
            if file.startswith("."):
                continue
            relative_path = os.path.relpath(
                os.path.join(root, file), agent.config.workspace_path
            )
            found_files.append(relative_path)

    return found_files

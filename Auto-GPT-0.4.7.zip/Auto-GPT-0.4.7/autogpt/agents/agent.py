from __future__ import annotations

import json
import time
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from autogpt.config import AIConfig, Config
    from autogpt.llm.base import ChatModelResponse, ChatSequence
    from autogpt.memory.vector import VectorMemory
    from autogpt.models.command_registry import CommandRegistry

from autogpt.json_utils.utilities import extract_dict_from_response, validate_dict
from autogpt.llm.api_manager import ApiManager
from autogpt.llm.base import Message
from autogpt.llm.utils import count_string_tokens
from autogpt.logs import logger
from autogpt.logs.log_cycle import (
    CURRENT_CONTEXT_FILE_NAME,
    FULL_MESSAGE_HISTORY_FILE_NAME,
    NEXT_ACTION_FILE_NAME,
    USER_INPUT_FILE_NAME,
    LogCycleHandler,
)
from autogpt.workspace import Workspace

from .base import AgentThoughts, BaseAgent, CommandArgs, CommandName


class Agent(BaseAgent):
    """与Auto-GPT交互的Agent类。"""

    def __init__(
        self,
        ai_config: AIConfig,
        command_registry: CommandRegistry,
        memory: VectorMemory,
        triggering_prompt: str,
        config: Config,
        cycle_budget: Optional[int] = None,
    ):
        super().__init__(
            ai_config=ai_config,
            command_registry=command_registry,
            config=config,
            default_cycle_instruction=triggering_prompt,
            cycle_budget=cycle_budget,
        )

        self.memory = memory
        """用于管理Agent上下文的VectorMemoryProvider（TODO）"""

        self.workspace = Workspace(config.workspace_path, config.restrict_to_workspace)
        """Agent可以访问的Workspace，用于读写文件等。"""

        self.created_at = datetime.now().strftime("%Y%m%d_%H%M%S")
        """Agent创建的时间戳；仅用于结构化调试日志。"""

        self.log_cycle_handler = LogCycleHandler()
        """用于结构化调试日志的LogCycleHandler。"""

    def construct_base_prompt(self, *args, **kwargs) -> ChatSequence:
        if kwargs.get("prepend_messages") is None:
            kwargs["prepend_messages"] = []

        # 时钟
        kwargs["prepend_messages"].append(
            Message("system", f"当前时间和日期是 {time.strftime('%c')}"),
        )

        # 将预算信息（如果有的话）添加到提示中
        api_manager = ApiManager()
        if api_manager.get_total_budget() > 0.0:
            remaining_budget = (
                api_manager.get_total_budget() - api_manager.get_total_cost()
            )
            if remaining_budget < 0:
                remaining_budget = 0

            budget_msg = Message(
                "system",
                f"您剩余的API预算为 ${remaining_budget:.3f}"
                + (
                    " 预算已用尽！关闭！\n\n"
                    if remaining_budget == 0
                    else " 预算几乎用尽！优雅地关闭！\n\n"
                    if remaining_budget < 0.005
                    else " 预算几乎用完，请尽快完成。\n\n"
                    if remaining_budget < 0.01
                    else ""
                ),
            )
            logger.debug(budget_msg)

            if kwargs.get("append_messages") is None:
                kwargs["append_messages"] = []
            kwargs["append_messages"].append(budget_msg)

        return super().construct_base_prompt(*args, **kwargs)

    def on_before_think(self, *args, **kwargs) -> ChatSequence:
        prompt = super().on_before_think(*args, **kwargs)

        self.log_cycle_handler.log_count_within_cycle = 0
        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            self.history.raw(),
            FULL_MESSAGE_HISTORY_FILE_NAME,
        )
        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            prompt.raw(),
            CURRENT_CONTEXT_FILE_NAME,
        )
        return prompt

    def execute(
        self,
        command_name: str | None,
        command_args: dict[str, str] | None,
        user_input: str | None,
    ) -> str:
        # 执行命令
        if command_name is not None and command_name.lower().startswith("error"):
            result = f"无法执行命令：{command_name}{command_args}"
        elif command_name == "human_feedback":
            result = f"人工反馈：{user_input}"
            self.log_cycle_handler.log_cycle(
                self.ai_config.ai_name,
                self.created_at,
                self.cycle_count,
                user_input,
                USER_INPUT_FILE_NAME,
            )

        else:
            for plugin in self.config.plugins:
                if not plugin.can_handle_pre_command():
                    continue
                command_name, arguments = plugin.pre_command(command_name, command_args)
            command_result = execute_command(
                command_name=command_name,
                arguments=command_args,
                agent=self,
            )
            result = f"命令 {command_name} 返回：{command_result}"

            result_tlength = count_string_tokens(str(command_result), self.llm.name)
            memory_tlength = count_string_tokens(
                str(self.history.summary_message()), self.llm.name
            )
            if result_tlength + memory_tlength > self.send_token_limit:
                result = f"失败：命令 {command_name} 返回的输出过多。请勿再次使用相同参数执行此命令。"

            for plugin in self.config.plugins:
                if not plugin.can_handle_post_command():
                    continue
                result = plugin.post_command(command_name, result)
        # 检查是否有命令的结果，将其附加到消息中
        if result is None:
            self.history.add("system", "无法执行命令", "action_result")
        else:
            self.history.add("system", result, "action_result")

        return result

    def parse_and_process_response(
        self, llm_response: ChatModelResponse, *args, **kwargs
    ) -> tuple[CommandName | None, CommandArgs | None, AgentThoughts]:
        if not llm_response.content:
            raise SyntaxError("Assistant response has no text content")

        assistant_reply_dict = extract_dict_from_response(llm_response.content)

        valid, errors = validate_dict(assistant_reply_dict, self.config)
        if not valid:
            raise SyntaxError(
                "Response validation failed:\n  "
                + ";\n  ".join([str(e) for e in errors])
            )

        for plugin in self.config.plugins:
            if not plugin.can_handle_post_planning():
                continue
            assistant_reply_dict = plugin.post_planning(assistant_reply_dict)

        response = None, None, assistant_reply_dict

        # 打印Assistant的想法
        if assistant_reply_dict != {}:
            # 获取命令名称和参数
            try:
                command_name, arguments = extract_command(
                    assistant_reply_dict, llm_response, self.config
                )
                response = command_name, arguments, assistant_reply_dict
            except Exception as e:
                logger.error("错误：\n", str(e))

        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            assistant_reply_dict,
            NEXT_ACTION_FILE_NAME,
        )
        return response


def extract_command(
    assistant_reply_json: dict, assistant_reply: ChatModelResponse, config: Config
) -> tuple[str, dict[str, str]]:
    """解析响应并返回命令名称和参数

    Args:
        assistant_reply_json (dict): 来自AI的响应对象
        assistant_reply (ChatModelResponse): AI的模型响应
        config (Config): 配置对象

    Returns:
        tuple: 命令名称和参数

    Raises:
        json.decoder.JSONDecodeError: 如果响应不是有效的JSON

        Exception: 如果发生其他任何错误
    """
    if config.openai_functions:
        if assistant_reply.function_call is None:
            return "错误：", {"message": "Assistant回复中没有'function_call'字段"}
        assistant_reply_json["command"] = {
            "name": assistant_reply.function_call.name,
            "args": json.loads(assistant_reply.function_call.arguments),
        }
    try:
        if "command" not in assistant_reply_json:
            return "错误：", {"message": "JSON中缺少'command'对象"}

        if not isinstance(assistant_reply_json, dict):
            return (
                "错误：",
                {
                    "message": f"之前发送的消息不是字典 {assistant_reply_json}"
                },
            )

        command = assistant_reply_json["command"]
        if not isinstance(command, dict):
            return "错误：", {"message": "'command'对象不是字典"}

        if "name" not in command:
            return "错误：", {"message": "'command'对象中缺少'name'字段"}

        command_name = command["name"]

        # 如果'command'对象中不存在'args'字段，则使用空字典
        arguments = command.get("args", {})

        return command_name, arguments
    except json.decoder.JSONDecodeError:
        return "错误：", {"message": "无效的JSON"}
    # 所有其他错误，返回"错误：" + 错误消息
    except Exception as e:
        return "错误：", {"message": str(e)}


def execute_command(
    command_name: str,
    arguments: dict[str, str],
    agent: Agent,
) -> Any:
    """执行命令并返回结果

    Args:
        command_name (str): 要执行的命令的名称
        arguments (dict): 命令的参数
        agent (Agent): 执行命令的Agent

    Returns:
        str: 命令的结果
    """
    try:
        # 执行具有相同名称或别名的本机命令，如果存在的话
        if command := agent.command_registry.get_command(command_name):
            return command(**arguments, agent=agent)

        # 处理非本机命令（例如来自插件的命令）
        for command in agent.ai_config.prompt_generator.commands:
            if (
                command_name == command.label.lower()
                or command_name == command.name.lower()
            ):
                return command.function(**arguments)

        raise RuntimeError(
            f"无法执行'{command_name}'：未知命令。请勿尝试再次使用此命令。"
        )
    except Exception as e:
        return f"错误：{str(e)}"

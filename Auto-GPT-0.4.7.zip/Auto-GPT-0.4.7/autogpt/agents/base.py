from __future__ import annotations

import re
from abc import ABCMeta, abstractmethod
from typing import TYPE_CHECKING, Any, Literal, Optional

if TYPE_CHECKING:
    from autogpt.config import AIConfig, Config

    from autogpt.models.command_registry import CommandRegistry

from autogpt.llm.base import ChatModelResponse, ChatSequence, Message
from autogpt.llm.providers.openai import OPEN_AI_CHAT_MODELS, get_openai_command_specs
from autogpt.llm.utils import count_message_tokens, create_chat_completion
from autogpt.logs import logger
from autogpt.memory.message_history import MessageHistory
from autogpt.prompts.prompt import DEFAULT_TRIGGERING_PROMPT

CommandName = str
CommandArgs = dict[str, str]
AgentThoughts = dict[str, Any]


class BaseAgent(metaclass=ABCMeta):
    """所有Auto-GPT代理的基类。"""

    ThoughtProcessID = Literal["one-shot"]

    def __init__(
        self,
        ai_config: AIConfig,
        command_registry: CommandRegistry,
        config: Config,
        big_brain: bool = True,
        default_cycle_instruction: str = DEFAULT_TRIGGERING_PROMPT,
        cycle_budget: Optional[int] = 1,
        send_token_limit: Optional[int] = None,
        summary_max_tlength: Optional[int] = None,
    ):
        self.ai_config = ai_config
        """与此代理关联的AIConfig或“个性”对象。"""

        self.command_registry = command_registry
        """包含代理可用的所有命令的注册表。"""

        self.config = config
        """适用的应用程序配置。"""

        self.big_brain = big_brain
        """
        此代理是否使用配置的智能LLM（默认）来思考，
        而不是配置的快速LLM。
        """

        self.default_cycle_instruction = default_cycle_instruction
        """传递给AI进行思考周期的默认指令。"""

        self.cycle_budget = cycle_budget
        """
        代理被允许无人监督地运行的周期数。

        `None`表示无限连续执行，
        `1`表示需要用户批准每一步，
        `0`表示停止代理。
        """

        self.cycles_remaining = cycle_budget
        """在`cycle_budget`内剩余的周期数。"""

        self.cycle_count = 0
        """自代理初始化以来已经运行的周期数。"""

        self.system_prompt = ai_config.construct_full_prompt(config)
        """
        系统提示设置AI的个性并解释其目标、可用资源和限制。
        """

        llm_name = self.config.smart_llm if self.big_brain else self.config.fast_llm
        self.llm = OPEN_AI_CHAT_MODELS[llm_name]
        """代理用于思考的LLM。"""

        self.send_token_limit = send_token_limit or self.llm.max_tokens * 3 // 4
        """
        用于构建提示的令牌限制。应保留用于完成的空间；
        默认为`llm.max_tokens`的75%。
        """

        self.history = MessageHistory(
            self.llm,
            max_summary_tlength=summary_max_tlength or self.send_token_limit // 6,
        )

    def think(
        self,
        instruction: Optional[str] = None,
        thought_process_id: ThoughtProcessID = "one-shot",
    ) -> tuple[CommandName | None, CommandArgs | None, AgentThoughts]:
        """运行代理一个周期。

        参数：
            instruction: 放在提示末尾的指令。

        返回：
            命令名称和参数（如果有）以及代理的思想。
        """

        instruction = instruction or self.default_cycle_instruction

        prompt: ChatSequence = self.construct_prompt(instruction, thought_process_id)
        prompt = self.on_before_think(prompt, thought_process_id, instruction)
        raw_response = create_chat_completion(
            prompt,
            self.config,
            functions=get_openai_command_specs(self.command_registry)
            if self.config.openai_functions
            else None,
        )
        self.cycle_count += 1

        return self.on_response(raw_response, thought_process_id, prompt, instruction)

    @abstractmethod
    def execute(
        self,
        command_name: str | None,
        command_args: dict[str, str] | None,
        user_input: str | None,
    ) -> str:
        """执行给定的命令（如果有）并返回代理的响应。

        参数：
            command_name: 要执行的命令的名称（如果有）。
            command_args: 要传递给命令的参数（如果有）。
            user_input: 用户的输入（如果有）。

        返回：
            命令的结果。
        """
        ...

    def construct_base_prompt(
        self,
        thought_process_id: ThoughtProcessID,
        prepend_messages: list[Message] = [],
        append_messages: list[Message] = [],
        reserve_tokens: int = 0,
    ) -> ChatSequence:
        """构建并返回一个带有以下结构的提示：
        1. 系统提示
        2. `prepend_messages`
        3. 代理的消息历史记录，根据需要截断并在前面添加运行摘要
        4. `append_messages`

        参数：
            prepend_messages: 要插入到系统提示和消息历史记录之间的消息
            append_messages: 要在消息历史记录之后插入的消息
            reserve_tokens: 为稍后添加的内容保留的令牌数量
        """

        prompt = ChatSequence.for_model(
            self.llm.name,
            [Message("system", self.system_prompt)] + prepend_messages,
        )

        # 为稍后追加的消息保留令牌
        reserve_tokens += self.history.max_summary_tlength
        if append_messages:
            reserve_tokens += count_message_tokens(append_messages, self.llm.name)

        # 填充消息历史记录，直到保留令牌的边缘。
        # 剪切剩余的历史消息并将其添加到运行摘要中。
        history_start_index = len(prompt)
        trimmed_history = add_history_upto_token_limit(
            prompt, self.history, self.send_token_limit - reserve_tokens
        )
        if trimmed_history:
            new_summary_msg, _ = self.history.trim_messages(list(prompt), self.config)
            prompt.insert(history_start_index, new_summary_msg)

        if append_messages:
            prompt.extend(append_messages)

        return prompt

    def construct_prompt(
        self,
        cycle_instruction: str,
        thought_process_id: ThoughtProcessID,
    ) -> ChatSequence:
        """构建并返回一个带有以下结构的提示：
        1. 系统提示
        2. 代理的消息历史记录，根据需要截断并在前面添加运行摘要
        3. `cycle_instruction`

        参数：
            cycle_instruction: 用于思考周期的最终指令
        """

        if not cycle_instruction:
            raise ValueError("未提供指令")

        cycle_instruction_msg = Message("user", cycle_instruction)
        cycle_instruction_tlength = count_message_tokens(
            cycle_instruction_msg, self.llm.name
        )

        append_messages: list[Message] = []

        response_format_instr = self.response_format_instruction(thought_process_id)
        if response_format_instr:
            append_messages.append(Message("system", response_format_instr))

        prompt = self.construct_base_prompt(
            thought_process_id,
            append_messages=append_messages,
            reserve_tokens=cycle_instruction_tlength,
        )

        # 添加用户输入消息（"触发提示"）
        prompt.append(cycle_instruction_msg)

        return prompt

    # 这可以扩展为支持代理内的多种类型的交互行为
    def response_format_instruction(self, thought_process_id: ThoughtProcessID) -> str:
        if thought_process_id != "one-shot":
            raise NotImplementedError(f"未知的思考过程'{thought_process_id}'")

        RESPONSE_FORMAT_WITH_COMMAND = """```ts
        interface Response {
            thoughts: {
                // 思考
                text: string;
                reasoning: string;
                // 传达长期计划的简短的markdown风格的项目列表
                plan: string;
                // 建设性的自我批评
                criticism: string;
                // 向用户说的思考摘要
                speak: string;
            };
            command: {
                name: string;
                args: Record<string, any>;
            };
        }
        ```"""

        RESPONSE_FORMAT_WITHOUT_COMMAND = """```ts
        interface Response {
            thoughts: {
                // 思考
                text: string;
                reasoning: string;
                // 传达长期计划的简短的markdown风格的项目列表
                plan: string;
                // 建设性的自我批评
                criticism: string;
                // 向用户说的思考摘要
                speak: string;
            };
        }
        ```"""

        response_format = re.sub(
            r"\n\s+",
            "\n",
            RESPONSE_FORMAT_WITHOUT_COMMAND
            if self.config.openai_functions
            else RESPONSE_FORMAT_WITH_COMMAND,
        )

        use_functions = self.config.openai_functions and self.command_registry.commands
        return (
            f"严格以JSON形式回应{', 并通过函数调用指定要使用的命令' if use_functions else ''}。"
            "JSON应与以下TypeScript类型'Response'兼容：\n"
            f"{response_format}\n"
        )

    def on_before_think(
        self,
        prompt: ChatSequence,
        thought_process_id: ThoughtProcessID,
        instruction: str,
    ) -> ChatSequence:
        """在构建提示但在执行之前调用。

        调用任何启用且能够插件的`on_planning`挂钩，将其输出添加到提示中。

        参数：
            instruction: 当前周期的指令，也用于构建提示

        返回：
            要执行的提示
        """
        current_tokens_used = prompt.token_length
        plugin_count = len(self.config.plugins)
        for i, plugin in enumerate(self.config.plugins):
            if not plugin.can_handle_on_planning():
                continue
            plugin_response = plugin.on_planning(
                self.ai_config.prompt_generator, prompt.raw()
            )
            if not plugin_response or plugin_response == "":
                continue
            message_to_add = Message("system", plugin_response)
            tokens_to_add = count_message_tokens(message_to_add, self.llm.name)
            if current_tokens_used + tokens_to_add > self.send_token_limit:
                logger.debug(f"插件响应过长，跳过：{plugin_response}")
                logger.debug(f"剩余插件在停止时：{plugin_count - i}")
                break
            prompt.insert(
                -1, message_to_add
            )  # HACK：假设周期指令在最后
            current_tokens_used += tokens_to_add
        return prompt

    def on_response(
        self,
        llm_response: ChatModelResponse,
        thought_process_id: ThoughtProcessID,
        prompt: ChatSequence,
        instruction: str,
    ) -> tuple[CommandName | None, CommandArgs | None, AgentThoughts]:
        """在从聊天模型接收响应时调用。

        将提示中的最后/最新消息和响应添加到`history`中，
        并调用`self.parse_and_process_response()`来完成剩下的工作。

        参数：
            llm_response: 从聊天模型得到的原始响应
            prompt: 执行的提示
            instruction: 当前周期的指令，也用于构建提示

        返回：
            解析后的命令名称和命令参数（如果有），以及代理的思想。
        """

        # 保存助手回复到消息历史记录
        self.history.append(prompt[-1])
        self.history.add(
            "assistant", llm_response.content, "ai_response"
        )  # FIXME：支持函数调用

        try:
            return self.parse_and_process_response(
                llm_response, thought_process_id, prompt, instruction
            )
        except SyntaxError as e:
            logger.error(f"无法解析响应：{e}")
            # TODO：调整此消息
            self.history.add(
                "system",
                f"无法解析您的响应：{e}"
                "\n\n请记住只能使用上面指定的格式进行响应！",
            )
            return None, None, {}

        # TODO：更新记忆/上下文

    @abstractmethod
    def parse_and_process_response(
        self,
        llm_response: ChatModelResponse,
        thought_process_id: ThoughtProcessID,
        prompt: ChatSequence,
        instruction: str,
    ) -> tuple[CommandName | None, CommandArgs | None, AgentThoughts]:
        """验证、解析和处理LLM的响应。

        必须由派生类实现：不提供基本实现，
        因为实现取决于派生代理的角色。

        参数：
            llm_response: 从聊天模型得到的原始响应
            prompt: 执行的提示
            instruction: 当前周期的指令，也用于构建提示

        返回：
            解析后的命令名称和命令参数（如果有），以及代理的思想。
        """
        pass


def add_history_upto_token_limit(
    prompt: ChatSequence, history: MessageHistory, t_limit: int
) -> list[Message]:
    current_prompt_length = prompt.token_length
    insertion_index = len(prompt)
    limit_reached = False
    trimmed_messages: list[Message] = []
    for cycle in reversed(list(history.per_cycle())):
        messages_to_add = [msg for msg in cycle if msg is not None]
        tokens_to_add = count_message_tokens(messages_to_add, prompt.model.name)
        if current_prompt_length + tokens_to_add > t_limit:
            limit_reached = True

        if not limit_reached:
            # 将最新的消息添加到链的开头，
            # 在系统提示之后。
            prompt.insert(insertion_index, *messages_to_add)
            current_prompt_length += tokens_to_add
        else:
            trimmed_messages = messages_to_add + trimmed_messages

    return trimmed_messages

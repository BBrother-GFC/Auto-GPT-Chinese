"""配置模块。"""
from __future__ import annotations

from typing import Literal

import click
from colorama import Back, Fore, Style

from autogpt import utils
from autogpt.config import Config
from autogpt.config.config import GPT_3_MODEL, GPT_4_MODEL
from autogpt.llm.api_manager import ApiManager
from autogpt.logs import logger
from autogpt.memory.vector import get_supported_memory_backends

def create_config(
    config: Config,
    continuous: bool,
    continuous_limit: int,
    ai_settings_file: str,
    prompt_settings_file: str,
    skip_reprompt: bool,
    speak: bool,
    debug: bool,
    gpt3only: bool,
    gpt4only: bool,
    memory_type: str,
    browser_name: str,
    allow_downloads: bool,
    skip_news: bool,
) -> None:
    """使用给定的参数更新配置对象。

    Args:
        continuous (bool): 是否运行在连续模式下
        continuous_limit (int): 连续模式下运行的次数
        ai_settings_file (str): ai_settings.yaml 文件的路径
        prompt_settings_file (str): prompt_settings.yaml 文件的路径
        skip_reprompt (bool): 是否跳过脚本开头的重新提示消息
        speak (bool): 是否启用说话模式
        debug (bool): 是否启用调试模式
        gpt3only (bool): 是否启用仅使用 GPT3.5 模式
        gpt4only (bool): 是否启用仅使用 GPT4 模式
        memory_type (str): 要使用的内存后端类型
        browser_name (str): 使用 Selenium 抓取网页时要使用的浏览器名称
        allow_downloads (bool): 是否允许 Auto-GPT 本地下载文件
        skip_news (bool): 是否抑制启动时最新消息的输出
    """
    config.debug_mode = False
    config.continuous_mode = False
    config.speak_mode = False

    if debug:
        logger.typewriter_log("调试模式: ", Fore.GREEN, "已启用")
        config.debug_mode = True

    if continuous:
        logger.typewriter_log("连续模式: ", Fore.RED, "已启用")
        logger.typewriter_log(
            "警告: ",
            Fore.RED,
            "不建议使用连续模式。它潜在风险较大，可能导致您的 AI 永远运行或执行您通常不授权的操作。请自行承担风险。",
        )
        config.continuous_mode = True

        if continuous_limit:
            logger.typewriter_log(
                "连续模式限制: ", Fore.GREEN, f"{continuous_limit}"
            )
            config.continuous_limit = continuous_limit

    # 检查是否在没有连续模式的情况下使用了连续模式限制
    if continuous_limit and not continuous:
        raise click.UsageError("--continuous-limit 只能在 --continuous 选项下使用")

    if speak:
        logger.typewriter_log("说话模式: ", Fore.GREEN, "已启用")
        config.speak_mode = True

    # 设置默认的 LLM 模型
    if gpt3only:
        logger.typewriter_log("仅使用 GPT3.5 模式: ", Fore.GREEN, "已启用")
        # --gpt3only 应始终使用 gpt-3.5-turbo，不管用户的 FAST_LLM 配置如何
        config.fast_llm = GPT_3_MODEL
        config.smart_llm = GPT_3_MODEL
    elif (
        gpt4only
        and check_model(GPT_4_MODEL, model_type="smart_llm", config=config)
        == GPT_4_MODEL
    ):
        logger.typewriter_log("仅使用 GPT4 模式: ", Fore.GREEN, "已启用")
        # --gpt4only 应始终使用 gpt-4，不管用户的 SMART_LLM 配置如何
        config.fast_llm = GPT_4_MODEL
        config.smart_llm = GPT_4_MODEL
    else:
        config.fast_llm = check_model(config.fast_llm, "fast_llm", config=config)
        config.smart_llm = check_model(config.smart_llm, "smart_llm", config=config)

    if memory_type:
        supported_memory = get_supported_memory_backends()
        chosen = memory_type
        if chosen not in supported_memory:
            logger.typewriter_log(
                "仅以下内存后端受支持: ",
                Fore.RED,
                f"{supported_memory}",
            )
            logger.typewriter_log("默认值: ", Fore.YELLOW, config.memory_backend)
        else:
            config.memory_backend = chosen

    if skip_reprompt:
        logger.typewriter_log("跳过重新提示: ", Fore.GREEN, "已启用")
        config.skip_reprompt = True

    if ai_settings_file:
        file = ai_settings_file

        # 验证文件
        (validated, message) = utils.validate_yaml_file(file)
        if not validated:
            logger.typewriter_log("验证文件失败", Fore.RED, message)
            logger.double_check()
            exit(1)

        logger.typewriter_log("使用 AI 设置文件:", Fore.GREEN, file)
        config.ai_settings_file = file
        config.skip_reprompt = True

    if prompt_settings_file:
        file = prompt_settings_file

        # 验证文件
        (validated, message) = utils.validate_yaml_file(file)
        if not validated:
            logger.typewriter_log("验证文件失败", Fore.RED, message)
            logger.double_check()
            exit(1)

        logger.typewriter_log("使用提示设置文件:", Fore.GREEN, file)
        config.prompt_settings_file = file

    if browser_name:
        config.selenium_web_browser = browser_name

    if allow_downloads:
        logger.typewriter_log("本地下载:", Fore.GREEN, "已启用")
        logger.typewriter_log(
            "警告: ",
            Fore.YELLOW,
            f"{Back.LIGHTYELLOW_EX}Auto-GPT 现在能够下载并保存文件到您的计算机。{Back.RESET} "
            + "建议您仔细监控它下载的任何文件。",
        )
        logger.typewriter_log(
            "警告: ",
            Fore.YELLOW,
            f"{Back.RED + Style.BRIGHT}始终记住不要打开您不确定的文件！{Style.RESET_ALL}",
        )
        config.allow_downloads = True

    if skip_news:
        config.skip_news = True

def check_model(
    model_name: str,
    model_type: Literal["smart_llm", "fast_llm"],
    config: Config,
) -> str:
    """检查模型是否可用。如果不可用，返回 gpt-3.5-turbo。"""
    openai_credentials = config.get_openai_credentials(model_name)
    api_manager = ApiManager()
    models = api_manager.get_models(**openai_credentials)

    if any(model_name in m["id"] for m in models):
        return model_name

    logger.typewriter_log(
        "警告: ",
        Fore.YELLOW,
        f"您无法访问 {model_name}。将 {model_type} 设置为 gpt-3.5-turbo。",
    )
    return "gpt-3.5-turbo"

if __name__ == "__main__":
    main()

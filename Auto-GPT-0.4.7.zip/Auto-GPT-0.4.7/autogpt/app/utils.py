import os
import re

import requests
from colorama import Fore, Style
from git.repo import Repo
from prompt_toolkit import ANSI, PromptSession
from prompt_toolkit.history import InMemoryHistory

from autogpt.config import Config
from autogpt.logs import logger

session = PromptSession(history=InMemoryHistory())


def clean_input(config: Config, prompt: str = "", talk=False):
    try:
        if config.chat_messages_enabled:
            for plugin in config.plugins:
                if not hasattr(plugin, "can_handle_user_input"):
                    continue
                if not plugin.can_handle_user_input(user_input=prompt):
                    continue
                plugin_response = plugin.user_input(user_input=prompt)
                if not plugin_response:
                    continue
                if plugin_response.lower() in [
                    "yes",
                    "yeah",
                    "y",
                    "ok",
                    "okay",
                    "sure",
                    "alright",
                    "是",
                    "嗯",
                    "是的",
                    "好的",
                    "可以",
                    "行",
                ]:
                    return config.authorize_key
                elif plugin_response.lower() in [
                    "no",
                    "nope",
                    "n",
                    "negative",
                    "否",
                    "不",
                    "不行",
                    "不可以",
                    "不好",
                ]:
                    return config.exit_key
                return plugin_response

        # 通过键盘询问用户
        logger.info("通过键盘询问用户...")

        # handle_sigint必须设置为False，以便在autogpt/main.py中正确使用信号处理程序。这是指
        # https://github.com/Significant-Gravitas/Auto-GPT/pull/4799/files/3966cdfd694c2a80c0333823c3bc3da090f85ed3#r1264278776
        answer = session.prompt(ANSI(prompt), handle_sigint=False)
        return answer
    except KeyboardInterrupt:
        logger.info("您中断了Auto-GPT")
        logger.info("退出...")
        exit(0)


def get_bulletin_from_web():
    try:
        response = requests.get(
            "https://raw.githubusercontent.com/Significant-Gravitas/Auto-GPT/master/BULLETIN.md"
        )
        if response.status_code == 200:
            return response.text
    except requests.exceptions.RequestException:
        pass

    return ""


def get_current_git_branch() -> str:
    try:
        repo = Repo(search_parent_directories=True)
        branch = repo.active_branch
        return branch.name
    except:
        return ""


def get_latest_bulletin() -> tuple[str, bool]:
    exists = os.path.exists("data/CURRENT_BULLETIN.md")
    current_bulletin = ""
    if exists:
        current_bulletin = open(
            "data/CURRENT_BULLETIN.md", "r", encoding="utf-8"
        ).read()
    new_bulletin = get_bulletin_from_web()
    is_new_news = new_bulletin != "" and new_bulletin != current_bulletin

    news_header = Fore.YELLOW + "欢迎使用Auto-GPT！\n"
    if new_bulletin or current_bulletin:
        news_header += (
            "以下是关于Auto-GPT最新消息和功能更新的信息！\n"
            "如果您不想看到这条消息，您可以使用*--skip-news*标志运行Auto-GPT。\n"
        )

    if new_bulletin and is_new_news:
        open("data/CURRENT_BULLETIN.md", "w", encoding="utf-8").write(new_bulletin)
        current_bulletin = f"{Fore.RED}::新公告::{Fore.RESET}\n\n{new_bulletin}"

    return f"{news_header}\n{current_bulletin}", is_new_news


def markdown_to_ansi_style(markdown: str):
    ansi_lines: list[str] = []
    for line in markdown.split("\n"):
        line_style = ""

        if line.startswith("# "):
            line_style += Style.BRIGHT
        else:
            line = re.sub(
                r"(?<!\*)\*(\*?[^*]+\*?)\*(?!\*)",
                rf"{Style.BRIGHT}\1{Style.NORMAL}",
                line,
            )

        if re.match(r"^#+ ", line) is not None:
            line_style += Fore.CYAN
            line = re.sub(r"^#+ ", "", line)

        ansi_lines.append(f"{line_style}{line}{Style.RESET_ALL}")
    return "\n".join(ansi_lines)


def get_legal_warning() -> str:
    legal_text = """
## 免责声明和赔偿协议
### 在使用AutoGPT系统之前，请仔细阅读此免责声明和赔偿协议。使用AutoGPT系统即表示您同意受此协议约束。

## 介绍
AutoGPT（以下简称“系统”）是一个将类似GPT的人工智能系统连接到互联网并允许其自动执行任务的项目。虽然系统旨在实用和高效，但可能会出现系统执行可能会造成伤害或产生意外后果的情况。

## 不对系统行为承担责任
AutoGPT项目的开发人员、贡献者和维护者（以下简称“项目方”）不提供明示或暗示的有关系统性能、准确性、可靠性或安全性的任何担保或陈述。通过使用系统，您了解并同意项目方对系统执行的任何行为或由此行为导致的任何后果均不承担责任。

## 用户责任和代表责任
作为系统的用户，您有责任监督和监控系统在您的代表下的行动。您承认使用系统可能会使您面临潜在的法律责任，包括但不限于代表责任，并同意承担与此类潜在责任相关的所有风险和责任。

## 赔偿
通过使用系统，您同意赔偿、捍卫并使项目方免受因您使用系统而引起的或与之相关的任何和所有索赔、责任、损害、损失或费用（包括合理的律师费和费用），包括但不限于系统代表您采取的任何行动、未能正确监督或监控系统以及由此产生的任何伤害或意外后果。
            """
    return legal_text

"""AutoGPT包的主要脚本。"""
from pathlib import Path
from typing import Optional

import click


@click.group(invoke_without_command=True)
@click.option("-c", "--continuous", is_flag=True, help="启用连续模式")
@click.option(
    "--skip-reprompt",
    "-y",
    is_flag=True,
    help="跳过脚本开头的重新提示消息",
)
@click.option(
    "--ai-settings",
    "-C",
    help=(
        "指定要使用的ai_settings.yaml文件，相对于Auto-GPT根目录。还会自动跳过重新提示。"
    ),
)
@click.option(
    "--prompt-settings",
    "-P",
    help="指定要使用的prompt_settings.yaml文件。",
)
@click.option(
    "-l",
    "--continuous-limit",
    type=int,
    help="定义在连续模式下运行的次数",
)
@click.option("--speak", is_flag=True, help="启用说话模式")
@click.option("--debug", is_flag=True, help="启用调试模式")
@click.option("--gpt3only", is_flag=True, help="启用仅GPT3.5模式")
@click.option("--gpt4only", is_flag=True, help="启用仅GPT4模式")
@click.option(
    "--use-memory",
    "-m",
    "memory_type",
    type=str,
    help="定义要使用的内存后端",
)
@click.option(
    "-b",
    "--browser-name",
    help="在使用Selenium抓取Web时指定要使用的Web浏览器。",
)
@click.option(
    "--allow-downloads",
    "--d",
    is_flag=True,
    help="危险操作：允许Auto-GPT原生下载文件。",
)
@click.option(
    "--skip-news",
    is_flag=True,
    help="指定是否在启动时抑制最新新闻的输出。",
)
@click.option(
    # TODO: 这是一个隐藏选项，目前用于集成测试。一旦准备好推出特定于代理的工作区，就应该将其公开。
    "--workspace-directory",
    "-w",
    type=click.Path(),
    hidden=True,
)
@click.option(
    "--install-plugin-deps",
    is_flag=True,
    help="安装第三方插件的外部依赖项。",
)
@click.option(
    "--ai-name",
    type=str,
    help="AI名称覆盖",
)
@click.option(
    "--ai-role",
    type=str,
    help="AI角色覆盖",
)
@click.option(
    "--ai-goal",
    type=str,
    multiple=True,
    help="AI目标覆盖；可以多次使用以传递多个目标",
)
@click.pass_context
def main(
    ctx: click.Context,
    continuous: bool,
    continuous_limit: int,
    ai_settings: str,
    prompt_settings: str,
    skip_reprompt: bool,
    speak: bool,
    debug: bool,
    gpt3only: bool,
    gpt4only: bool,
    memory_type: str,
    browser_name: str,
    allow_downloads: bool,
    skip_news: bool,
    workspace_directory: str,
    install_plugin_deps: bool,
    ai_name: Optional[str],
    ai_role: Optional[str],
    ai_goal: tuple[str],
) -> None:
    """
    欢迎使用AutoGPT，这是一个实验性的开源应用程序，展示了GPT-4的能力，推动了AI的边界。

    启动Auto-GPT助手。
    """
    # 将导入放在函数内部，以避免在启动CLI时导入所有内容
    from autogpt.app.main import run_auto_gpt

    if ctx.invoked_subcommand is None:
        run_auto_gpt(
            continuous=continuous,
            continuous_limit=continuous_limit,
            ai_settings=ai_settings,
            prompt_settings=prompt_settings,
            skip_reprompt=skip_reprompt,
            speak=speak,
            debug=debug,
            gpt3only=gpt3only,
            gpt4only=gpt4only,
            memory_type=memory_type,
            browser_name=browser_name,
            allow_downloads=allow_downloads,
            skip_news=skip_news,
            working_directory=Path(
                __file__
            ).parent.parent.parent,  # TODO: 将此作为选项
            workspace_directory=workspace_directory,
            install_plugin_deps=install_plugin_deps,
            ai_name=ai_name,
            ai_role=ai_role,
            ai_goals=ai_goal,
        )


if __name__ == "__main__":
    main()

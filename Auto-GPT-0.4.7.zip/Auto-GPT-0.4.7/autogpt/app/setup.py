"""设置AI及其目标"""
import re
from typing import Optional

from colorama import Fore, Style
from jinja2 import Template

from autogpt.app import utils
from autogpt.config import Config
from autogpt.config.ai_config import AIConfig
from autogpt.llm.base import ChatSequence, Message
from autogpt.llm.utils import create_chat_completion
from autogpt.logs import logger
from autogpt.prompts.default_prompts import (
    DEFAULT_SYSTEM_PROMPT_AICONFIG_AUTOMATIC,
    DEFAULT_TASK_PROMPT_AICONFIG_AUTOMATIC,
    DEFAULT_USER_DESIRE_PROMPT,
)


def prompt_user(
    config: Config, ai_config_template: Optional[AIConfig] = None
) -> AIConfig:
    """提示用户输入

    参数:
        config (Config): Config对象
        ai_config_template (AIConfig): 用作模板的AIConfig对象

    返回:
        AIConfig: 根据用户输入定制的AIConfig对象
    """

    # 构建提示
    logger.typewriter_log(
        "欢迎使用Auto-GPT！",
        "Auto-GPT-Chinese来自 BBrother",
        "Auto-GPT-Chinese 仓库链接https://github.com/gfc090110/Auto-GPT-Chinese",
        "汉化全是机翻的，请见谅",
        Fore.GREEN,
        "运行时使用'--help'以获取更多信息。",
        speak_text=True,
    )

    ai_config_template_provided = ai_config_template is not None and any(
        [
            ai_config_template.ai_goals,
            ai_config_template.ai_name,
            ai_config_template.ai_role,
        ]
    )

    user_desire = ""
    if not ai_config_template_provided:
        # 如果没有传入命令行参数，则获取用户需求
        logger.typewriter_log(
            "创建一个AI助手:",
            Fore.GREEN,
            "输入'--manual'以进入手动模式。",
            speak_text=True,
        )

        user_desire = utils.clean_input(
            config, f"{Fore.LIGHTBLUE_EX}我希望Auto-GPT能够{Style.RESET_ALL}: "
        )

    if user_desire.strip() == "":
        user_desire = DEFAULT_USER_DESIRE_PROMPT  # 默认提示

    # 如果用户需求包含"--manual"或者我们覆盖了AI配置的任何部分
    if "--manual" in user_desire or ai_config_template_provided:
        logger.typewriter_log(
            "已选择手动模式",
            Fore.GREEN,
            speak_text=True,
        )
        return generate_aiconfig_manual(config, ai_config_template)

    else:
        try:
            return generate_aiconfig_automatic(user_desire, config)
        except Exception as e:
            logger.typewriter_log(
                "无法根据用户需求自动生成AI配置。",
                Fore.RED,
                "回退到手动模式。",
                speak_text=True,
            )
            logger.debug(f"AIConfig生成过程中出错: {e}")

            return generate_aiconfig_manual(config)


def generate_aiconfig_manual(
    config: Config, ai_config_template: Optional[AIConfig] = None
) -> AIConfig:
    """
    通过提示用户提供AI的名称、角色和目标来交互式地创建AI配置。

    此函数将引导用户完成一系列提示，以收集创建AIConfig对象所需的信息。用户将被要求提供AI的名称和角色，以及最多五个目标。如果用户未为任何字段提供值，将使用默认值。

    参数:
        config (Config): Config对象
        ai_config_template (AIConfig): 用作模板的AIConfig对象

    返回:
        AIConfig: 包含用户定义或默认AI名称、角色和目标的AIConfig对象。
    """

    # 手动设置介绍
    logger.typewriter_log(
        "创建一个AI助手:",
        Fore.GREEN,
        "在下面输入您的AI的名称和角色。不输入任何内容将加载默认值。",
        speak_text=True,
    )

    if ai_config_template and ai_config_template.ai_name:
        ai_name = ai_config_template.ai_name
    else:
        ai_name = ""
        # 从用户获取AI名称
        logger.typewriter_log(
            "给您的AI命名: ", Fore.GREEN, "例如，'创业家-GPT'"
        )
        ai_name = utils.clean_input(config, "AI名称: ")
    if ai_name == "":
        ai_name = "创业家-GPT"

    logger.typewriter_log(
        f"{ai_name}在此!", Fore.LIGHTBLUE_EX, "我随时为您服务。", speak_text=True
    )

    if ai_config_template and ai_config_template.ai_role:
        ai_role = ai_config_template.ai_role
    else:
        # 从用户获取AI角色
        logger.typewriter_log(
            "描述您的AI的角色: ",
            Fore.GREEN,
            "例如，'一个旨在自主开发和经营企业以增加您的净资产为唯一目标的AI.'",
        )
        ai_role = utils.clean_input(config, f"{ai_name}是: ")
    if ai_role == "":
        ai_role = "一个旨在自主开发和经营企业以增加您的净资产为唯一目标的AI。"

    if ai_config_template and ai_config_template.ai_goals:
        ai_goals = ai_config_template.ai_goals
    else:
        # 为AI输入最多5个目标
        logger.typewriter_log(
            "为您的AI输入最多5个目标: ",
            Fore.GREEN,
            "例如：\n增加净资产、增加Twitter粉丝、自主开发和管理多个企业",
        )
        logger.info("不输入内容以加载默认值，完成后不输入任何内容。")
        ai_goals = []
        for i in range(5):
            ai_goal = utils.clean_input(
                config, f"{Fore.LIGHTBLUE_EX}目标{Style.RESET_ALL} {i+1}: "
            )
            if ai_goal == "":
                break
            ai_goals.append(ai_goal)
    if not ai_goals:
        ai_goals = [
            "增加净资产",
            "增加Twitter粉丝",
            "自主开发和管理多个企业",
        ]

    # 从用户获取API调用预算
    logger.typewriter_log(
        "输入您的API调用预算: ",
        Fore.GREEN,
        "例如：$1.50",
    )
    logger.info("不输入内容以让AI无限制运行")
    api_budget_input = utils.clean_input(
        config, f"{Fore.LIGHTBLUE_EX}预算{Style.RESET_ALL}: $"
    )
    if api_budget_input == "":
        api_budget = 0.0
    else:
        try:
            api_budget = float(api_budget_input.replace("$", ""))
        except ValueError:
            logger.typewriter_log(
                "无效的预算输入。将预算设置为无限制。", Fore.RED
            )
            api_budget = 0.0

    return AIConfig(ai_name, ai_role, ai_goals, api_budget)


def generate_aiconfig_automatic(user_prompt: str, config: Config) -> AIConfig:
    """从给定的字符串生成AIConfig对象。

    返回:
    AIConfig: 根据用户输入定制的AIConfig对象
    """

    system_prompt = DEFAULT_SYSTEM_PROMPT_AICONFIG_AUTOMATIC
    prompt_ai_config_automatic = Template(
        DEFAULT_TASK_PROMPT_AICONFIG_AUTOMATIC
    ).render(user_prompt=user_prompt)
    # 调用LLM，以字符串作为用户输入
    output = create_chat_completion(
        ChatSequence.for_model(
            config.fast_llm,
            [
                Message("system", system_prompt),
                Message("user", prompt_ai_config_automatic),
            ],
        ),
        config,
    ).content

    # 调试LLM输出
    logger.debug(f"AI配置生成器原始输出：{output}")

    # 解析输出
    ai_name = re.search(r"Name(?:\s*):(?:\s*)(.*)", output, re.IGNORECASE).group(1)
    ai_role = (
        re.search(
            r"Description(?:\s*):(?:\s*)(.*?)(?:(?:\n)|Goals)",
            output,
            re.IGNORECASE | re.DOTALL,
        )
        .group(1)
        .strip()
    )
    ai_goals = re.findall(r"(?<=\n)-\s*(.*)", output)
    api_budget = 0.0  # TODO: 使用正则表达式解析API预算

    return AIConfig(ai_name, ai_role, ai_goals, api_budget)

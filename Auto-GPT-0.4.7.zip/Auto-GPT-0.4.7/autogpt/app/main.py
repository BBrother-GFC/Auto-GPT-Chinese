"""应用程序入口点。可以由CLI或任何其他前端应用程序调用。"""
import enum
import logging
import math
import signal
import sys
from pathlib import Path
from types import FrameType
from typing import Optional

from colorama import Fore, Style

from autogpt.agents import Agent, AgentThoughts, CommandArgs, CommandName
from autogpt.app.configurator import create_config
from autogpt.app.setup import prompt_user
from autogpt.app.spinner import Spinner
from autogpt.app.utils import (
    clean_input,
    get_current_git_branch,
    get_latest_bulletin,
    get_legal_warning,
    markdown_to_ansi_style,
)
from autogpt.commands import COMMAND_CATEGORIES
from autogpt.config import AIConfig, Config, ConfigBuilder, check_openai_api_key
from autogpt.llm.api_manager import ApiManager
from autogpt.logs import logger
from autogpt.memory.vector import get_memory
from autogpt.models.command_registry import CommandRegistry
from autogpt.plugins import scan_plugins
from autogpt.prompts.prompt import DEFAULT_TRIGGERING_PROMPT
from autogpt.speech import say_text
from autogpt.workspace import Workspace
from scripts.install_plugin_deps import install_plugin_dependencies


def run_auto_gpt(
    continuous: bool,
    continuous_limit: int,
    ai_settings: str,
    prompt_settings: str,
    skip_reprompt: bool,
    speak: bool,
    debug: bool,
    gpt3only: bool,
    gpt4only: bool,
    memory_type: str,
    browser_name: str,
    allow_downloads: bool,
    skip_news: bool,
    working_directory: Path,
    workspace_directory: str | Path,
    install_plugin_deps: bool,
    ai_name: Optional[str] = None,
    ai_role: Optional[str] = None,
    ai_goals: tuple[str] = tuple(),
):
    # 在做任何其他操作之前配置日志记录。
    logger.set_level(logging.DEBUG if debug else logging.INFO)

    config = ConfigBuilder.build_config_from_env(workdir=working_directory)

    # HACK: 这是一个允许配置进入日志记录器的小技巧，而不必在各处传递或直接导入它的小技巧。
    logger.config = config

    # TODO: 填写此处的llm值
    check_openai_api_key(config)

    create_config(
        config,
        continuous,
        continuous_limit,
        ai_settings,
        prompt_settings,
        skip_reprompt,
        speak,
        debug,
        gpt3only,
        gpt4only,
        memory_type,
        browser_name,
        allow_downloads,
        skip_news,
    )

    if config.continuous_mode:
        for line in get_legal_warning().split("\n"):
            logger.warn(markdown_to_ansi_style(line), "LEGAL:", Fore.RED)

    if not config.skip_news:
        motd, is_new_motd = get_latest_bulletin()
        if motd:
            motd = markdown_to_ansi_style(motd)
            for motd_line in motd.split("\n"):
                logger.info(motd_line, "NEWS:", Fore.GREEN)
            if is_new_motd and not config.chat_messages_enabled:
                input(
                    Fore.MAGENTA
                    + Style.BRIGHT
                    + "NEWS: 公告已更新！按Enter继续..."
                    + Style.RESET_ALL
                )

        git_branch = get_current_git_branch()
        if git_branch and git_branch != "stable":
            logger.typewriter_log(
                "警告: ",
                Fore.RED,
                f"您正在使用`{git_branch}`分支，这不是一个受支持的分支。",
            )
        if sys.version_info < (3, 10):
            logger.typewriter_log(
                "警告: ",
                Fore.RED,
                "您正在使用较旧版本的Python。"
                "某些情况下，某些部分的Auto-GPT会出现问题。"
                "请考虑升级到Python 3.10或更高版本。",
            )

    if install_plugin_deps:
        install_plugin_dependencies()

    # TODO: 让此目录存在于存储库之外（例如在用户的主目录中），
    # 并将其作为命令行参数或环境文件的一部分传递进来。
    config.workspace_path = Workspace.init_workspace_directory(
        config, workspace_directory
    )

    # HACK: 在这里执行此操作以收集一些依赖于工作区的全局值。
    config.file_logger_path = Workspace.build_file_logger_path(config.workspace_path)

    config.plugins = scan_plugins(config, config.debug_mode)

    # 创建一个CommandRegistry实例并扫描默认文件夹
    command_registry = CommandRegistry.with_command_modules(COMMAND_CATEGORIES, config)

    ai_config = construct_main_ai_config(
        config,
        name=ai_name,
        role=ai_role,
        goals=ai_goals,
    )
    ai_config.command_registry = command_registry

    # 添加能够向日志记录器报告的聊天插件
    if config.chat_messages_enabled:
        for plugin in config.plugins:
            if hasattr(plugin, "can_handle_report") and plugin.can_handle_report():
                logger.info(f"加载插件到日志记录器: {plugin.__class__.__name__}")
                logger.chat_plugins.append(plugin)

    # 初始化内存并确保它是空的。
    # 对于索引和引用Pinecone内存来说尤为重要。
    memory = get_memory(config)
    memory.clear()
    logger.typewriter_log(
        "使用的内存类型:", Fore.GREEN, f"{memory.__class__.__name__}"
    )
    logger.typewriter_log("使用的浏览器:", Fore.GREEN, config.selenium_web_browser)

    agent = Agent(
        memory=memory,
        command_registry=command_registry,
        triggering_prompt=DEFAULT_TRIGGERING_PROMPT,
        ai_config=ai_config,
        config=config,
    )

    run_interaction_loop(agent)


def _get_cycle_budget(continuous_mode: bool, continuous_limit: int) -> int | None:
    # 从continuous_mode/continuous_limit配置翻译为cycle_budget
    # （不检查用户的最大运行周期）以及在我们与用户检查之前的剩余周期数。
    if continuous_mode:
        cycle_budget = continuous_limit if continuous_limit else math.inf
    else:
        cycle_budget = 1

    return cycle_budget


class UserFeedback(str, enum.Enum):
    """用户反馈的枚举。"""

    授权 = "生成下一个命令JSON"
    退出 = "退出"
    文本 = "文本"


def run_interaction_loop(
    agent: Agent,
) -> None:
    """运行代理的主交互循环。

    Args:
        agent: 要运行交互循环的代理。

    Returns:
        None
    """
    # 这些包含应用程序配置和代理配置，因此在这里获取它们。
    config = agent.config
    ai_config = agent.ai_config
    logger.debug(f"{ai_config.ai_name} 系统提示: {agent.system_prompt}")

    cycle_budget = cycles_remaining = _get_cycle_budget(
        config.continuous_mode, config.continuous_limit
    )
    spinner = Spinner("思考中...", plain_output=config.plain_output)

    def graceful_agent_interrupt(signum: int, frame: Optional[FrameType]) -> None:
        nonlocal cycle_budget, cycles_remaining, spinner
        if cycles_remaining in [0, 1, math.inf]:
            logger.typewriter_log(
                "接收到中断信号。立即停止连续命令执行。",
                Fore.RED,
            )
            sys.exit()
        else:
            restart_spinner = spinner.running
            if spinner.running:
                spinner.stop()

            logger.typewriter_log(
                "接收到中断信号。停止连续命令执行。",
                Fore.RED,
            )
            cycles_remaining = 1
            if restart_spinner:
                spinner.start()

    # 为代理设置一个中断信号。
    signal.signal(signal.SIGINT, graceful_agent_interrupt)

    #########################
    # 应用程序主循环 #
    #########################

    while cycles_remaining > 0:
        logger.debug(f"循环预算: {cycle_budget}; 剩余: {cycles_remaining}")

        ########
        # 计划 #
        ########
        # 让代理确定要采取的下一步操作。
        with spinner:
            command_name, command_args, assistant_reply_dict = agent.think()

        ###############
        # 更新用户 #
        ###############
        # 打印助手的思维和下一步命令给用户。
        update_user(config, ai_config, command_name, command_args, assistant_reply_dict)

        ##################
        # 获取用户输入 #
        ##################
        if cycles_remaining == 1:  # 最后一个周期
            user_feedback, user_input, new_cycles_remaining = get_user_feedback(
                config,
                ai_config,
            )

            if user_feedback == UserFeedback.授权:
                if new_cycles_remaining is not None:
                    # 情况1：用户正在更改周期预算。
                    if cycle_budget > 1:
                        cycle_budget = new_cycles_remaining + 1
                    # 情况2：用户正在连续运行，并且
                    # 启动一次性连续周期
                    cycles_remaining = new_cycles_remaining + 1
                else:
                    # 情况1：连续迭代被中断 -> 恢复
                    if cycle_budget > 1:
                        logger.typewriter_log(
                            "继续连续执行: ",
                            Fore.MAGENTA,
                            f"周期预算为 {cycle_budget}。",
                        )
                    # 情况2：代理用尽了周期预算 -> 重置
                    cycles_remaining = cycle_budget + 1
                logger.typewriter_log(
                    "-=-=-=-=-=-=-= 用户授权的命令 -=-=-=-=-=-=-=",
                    Fore.MAGENTA,
                    "",
                )
            elif user_feedback == UserFeedback.退出:
                logger.typewriter_log("退出...", Fore.YELLOW)
                exit()
            else:  # user_feedback == UserFeedback.文本
                command_name = "human_feedback"
        else:
            user_input = None
            # 首先记录换行符，以便用户可以更好地在控制台中区分各个部分
            logger.typewriter_log("\n")
            if cycles_remaining != math.inf:
                # 打印授权的剩余命令值
                logger.typewriter_log(
                    "剩余的授权命令: ", Fore.CYAN, f"{cycles_remaining}"
                )

        ###################
        # 执行命令 #
        ###################
        # 首先减少周期计数器，以减少在执行命令期间发生SIGINT的可能性，
        # 将剩余周期数设置为1，然后将减量设置为0，退出应用程序。
        if command_name != "human_feedback":
            cycles_remaining -= 1
        result = agent.execute(command_name, command_args, user_input)

        if result is not None:
            logger.typewriter_log("系统: ", Fore.YELLOW, result)
        else:
            logger.typewriter_log("系统: ", Fore.YELLOW, "无法执行命令")


def update_user(
    config: Config,
    ai_config: AIConfig,
    command_name: CommandName | None,
    command_args: CommandArgs | None,
    assistant_reply_dict: AgentThoughts,
) -> None:
    """将助手的思维和下一步命令打印给用户。

    Args:
        config: 程序的配置。
        ai_config: AI的配置。
        command_name: 要执行的命令的名称。
        command_args: 命令的参数。
        assistant_reply_dict: 助手的回复。

    Returns:
        None
    """

    print_assistant_thoughts(ai_config.ai_name, assistant_reply_dict, config)

    if command_name is not None:
        if command_name.lower().startswith("error"):
            logger.typewriter_log(
                "错误: ",
                Fore.RED,
                f"代理未能选择一个动作。"
                f"错误消息: {command_name}",
            )
        else:
            if config.speak_mode:
                say_text(f"我要执行 {command_name}", config)

            # 首先记录换行符，以便用户可以更好地在控制台中区分各个部分
            logger.typewriter_log("\n")
            logger.typewriter_log(
                "下一步操作: ",
                Fore.CYAN,
                f"命令 = {Fore.CYAN}{remove_ansi_escape(command_name)}{Style.RESET_ALL}  "
                f"参数 = {Fore.CYAN}{command_args}{Style.RESET_ALL}",
            )
    else:
        logger.typewriter_log(
            "未选择任何操作: ",
            Fore.RED,
            f"代理未能选择一个动作。",
        )


def get_user_feedback(
    config: Config,
    ai_config: AIConfig,
) -> tuple[UserFeedback, str, int | None]:
    """获取用户对助手回复的反馈。

    Args:
        config: 程序的配置。
        ai_config: AI的配置。

    Returns:
        一个元组，包括用户的反馈、用户的输入和用户是否启动了连续周期时的剩余周期数。
    """
    # ### 获取用户授权执行命令 ###
    # 获取按键：提示用户按Enter继续或按Esc退出
    logger.info(
        f"输入 '{config.authorise_key}' 以授权命令，"
        f"'{config.authorise_key} -N' 以运行 N 个连续命令，"
        f"'{config.exit_key}' 退出程序，或输入 {ai_config.ai_name} 的反馈..."
    )

    user_feedback = None
    user_input = ""
    new_cycles_remaining = None

    while user_feedback is None:
        # 从用户获取输入
        if config.chat_messages_enabled:
            console_input = clean_input(config, "等待您的回复...")
        else:
            console_input = clean_input(
                config, Fore.MAGENTA + "输入:" + Style.RESET_ALL
            )

        # 解析用户输入
        if console_input.lower().strip() == config.authorise_key:
            user_feedback = UserFeedback.授权
        elif console_input.lower().strip() == "":
            logger.warn("无效的输入格式。")
        elif console_input.lower().startswith(f"{config.authorise_key} -"):
            try:
                user_feedback = UserFeedback.授权
                new_cycles_remaining = abs(int(console_input.split(" ")[1]))
            except ValueError:
                logger.warn(
                    f"无效的输入格式。"
                    f"请键入 '{config.authorise_key} -N'"
                    "，其中 N 是连续任务的数量。"
                )
        elif console_input.lower() in [config.exit_key, "exit"]:
            user_feedback = UserFeedback.退出
        else:
            user_feedback = UserFeedback.文本
            user_input = console_input

    return user_feedback, user_input, new_cycles_remaining


def construct_main_ai_config(
    config: Config,
    name: Optional[str] = None,
    role: Optional[str] = None,
    goals: tuple[str] = tuple(),
) -> AIConfig:
    """构建AI要回应的提示

    Returns:
        str: 提示字符串
    """
    ai_config = AIConfig.load(config.workdir / config.ai_settings_file)

    # 应用覆盖
    if name:
        ai_config.ai_name = name
    if role:
        ai_config.ai_role = role
    if goals:
        ai_config.ai_goals = list(goals)

    if (
        all([name, role, goals])
        or config.skip_reprompt
        and all([ai_config.ai_name, ai_config.ai_role, ai_config.ai_goals])
    ):
        logger.typewriter_log("名称 :", Fore.GREEN, ai_config.ai_name)
        logger.typewriter_log("角色 :", Fore.GREEN, ai_config.ai_role)
        logger.typewriter_log("目标:", Fore.GREEN, f"{ai_config.ai_goals}")
        logger.typewriter_log(
            "API 预算:",
            Fore.GREEN,
            "无限" if ai_config.api_budget <= 0 else f"${ai_config.api_budget}",
        )
    elif all([ai_config.ai_name, ai_config.ai_role, ai_config.ai_goals]):
        logger.typewriter_log(
            "欢迎回来！ ",
            Fore.GREEN,
            f"您是否希望我继续作为 {ai_config.ai_name}？",
            speak_text=True,
        )
        should_continue = clean_input(
            config,
            f"""继续使用上次的设置吗？
名称:  {ai_config.ai_name}
角色:  {ai_config.ai_role}
目标: {ai_config.ai_goals}
API 预算: {"无限" if ai_config.api_budget <= 0 else f"${ai_config.api_budget}"}
继续 ({config.authorise_key}/{config.exit_key}): """,
        )
        if should_continue.lower() == config.exit_key:
            ai_config = AIConfig()

    if any([not ai_config.ai_name, not ai_config.ai_role, not ai_config.ai_goals]):
        ai_config = prompt_user(config)
        ai_config.save(config.workdir / config.ai_settings_file)

    if config.restrict_to_workspace:
        logger.typewriter_log(
            "注意：由此代理创建的所有文件/目录都可以在其工作区中找到：",
            Fore.YELLOW,
            f"{config.workspace_path}",
        )
    # 设置总API预算
    api_manager = ApiManager()
    api_manager.set_total_budget(ai_config.api_budget)

    # 代理已创建，打印消息
    logger.typewriter_log(
        ai_config.ai_name,
        Fore.LIGHTBLUE_EX,
        "已创建，具有以下详细信息：",
        speak_text=True,
    )

    # 打印ai_config的详细信息
    # 名称
    logger.typewriter_log("名称:", Fore.GREEN, ai_config.ai_name, speak_text=False)
    # 角色
    logger.typewriter_log("角色:", Fore.GREEN, ai_config.ai_role, speak_text=False)
    # 目标
    logger.typewriter_log("目标:", Fore.GREEN, "", speak_text=False)
    for goal in ai_config.ai_goals:
        logger.typewriter_log("-", Fore.GREEN, goal, speak_text=False)

    return ai_config


def print_assistant_thoughts(
    ai_name: str,
    assistant_reply_json_valid: dict,
    config: Config,
) -> None:
    from autogpt.speech import say_text

    assistant_thoughts_reasoning = None
    assistant_thoughts_plan = None
    assistant_thoughts_speak = None
    assistant_thoughts_criticism = None

    assistant_thoughts = assistant_reply_json_valid.get("thoughts", {})
    assistant_thoughts_text = remove_ansi_escape(assistant_thoughts.get("text", ""))
    if assistant_thoughts:
        assistant_thoughts_reasoning = remove_ansi_escape(
            assistant_thoughts.get("reasoning", "")
        )
        assistant_thoughts_plan = remove_ansi_escape(assistant_thoughts.get("plan", ""))
        assistant_thoughts_criticism = remove_ansi_escape(
            assistant_thoughts.get("criticism", "")
        )
        assistant_thoughts_speak = remove_ansi_escape(
            assistant_thoughts.get("speak", "")
        )
    logger.typewriter_log(
        f"{ai_name.upper()} 思考:", Fore.YELLOW, assistant_thoughts_text
    )
    logger.typewriter_log("推理:", Fore.YELLOW, str(assistant_thoughts_reasoning))
    if assistant_thoughts_plan:
        logger.typewriter_log("计划:", Fore.YELLOW, "")
        # 如果是列表，则将其连接成字符串
        if isinstance(assistant_thoughts_plan, list):
            assistant_thoughts_plan = "\n".join(assistant_thoughts_plan)
        elif isinstance(assistant_thoughts_plan, dict):
            assistant_thoughts_plan = str(assistant_thoughts_plan)

        # 使用换行符和破折号拆分输入字符串
        lines = assistant_thoughts_plan.split("\n")
        for line in lines:
            logger.typewriter_log(" -", Fore.YELLOW, line)
    logger.typewriter_log("批评:", Fore.YELLOW, str(assistant_thoughts_criticism))
    if assistant_thoughts_speak:
        logger.typewriter_log("总结:", Fore.YELLOW, "")
        # 如果是列表，则将其连接成字符串
        if isinstance(assistant_thoughts_speak, list):
            assistant_thoughts_speak = "\n".join(assistant_thoughts_speak)
        elif isinstance(assistant_thoughts_speak, dict):
            assistant_thoughts_speak = str(assistant_thoughts_speak)

        # 使用换行符和破折号拆分输入字符串
        lines = assistant_thoughts_speak.split("\n")
        for line in lines:
            logger.typewriter_log(" -", Fore.YELLOW, line)

    # 如果启用了speak_mode，则使用文本转语音将助手的思维转换为音频。
    if config.speak_mode:
        if assistant_thoughts_speak:
            say_text(assistant_thoughts_speak, config)
        else:
            say_text(assistant_thoughts_text, config)


def remove_ansi_escape(text: str) -> str:
    """从文本中移除ANSI转义序列。

    Args:
        text (str): 包含ANSI转义序列的文本。

    Returns:
        str: 移除ANSI转义序列后的文本。
    """
    import re

    ansi_escape = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
    return ansi_escape.sub("", text)


if __name__ == "__main__":
    run_auto_gpt(
        continuous=False,
        continuous_limit=5,
        ai_settings="gpt-3.5-turbo",
        prompt_settings="multi",
        skip_reprompt=False,
        speak=False,
        debug=False,
        gpt3only=False,
        gpt4only=False,
        memory_type="local",
        browser_name="chrome",
        allow_downloads=True,
        skip_news=False,
        working_directory=Path.cwd(),
        workspace_directory="",
        install_plugin_deps=False,
    )

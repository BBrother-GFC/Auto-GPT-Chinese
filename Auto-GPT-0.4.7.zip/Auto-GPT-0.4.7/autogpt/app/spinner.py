"""一个简单的旋转模块"""
import itertools
import sys
import threading
import time

class Spinner:
    """一个简单的旋转类"""

    def __init__(
        self,
        message: str = "加载中...",
        delay: float = 0.1,
        plain_output: bool = False,
    ) -> None:
        """初始化旋转类

        Args:
            message (str): 要显示的消息。
            delay (float): 每次旋转更新之间的延迟。
            plain_output (bool): 是否显示旋转器。
        """
        self.plain_output = plain_output
        self.spinner = itertools.cycle(["-", "/", "|", "\\"])
        self.delay = delay
        self.message = message
        self.running = False
        self.spinner_thread = None

    def spin(self) -> None:
        """旋转旋转器"""
        if self.plain_output:
            self.print_message()
            return
        while self.running:
            self.print_message()
            time.sleep(self.delay)

    def print_message(self):
        sys.stdout.write(f"\r{' ' * (len(self.message) + 2)}\r")
        sys.stdout.write(f"{next(self.spinner)} {self.message}\r")
        sys.stdout.flush()

    def start(self):
        self.running = True
        self.spinner_thread = threading.Thread(target=self.spin)
        self.spinner_thread.start()

    def stop(self):
        self.running = False
        if self.spinner_thread is not None:
            self.spinner_thread.join()
        sys.stdout.write(f"\r{' ' * (len(self.message) + 2)}\r")
        sys.stdout.flush()

    def __enter__(self):
        """启动旋转器"""
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback) -> None:
        """停止旋转器

        Args:
            exc_type (Exception): 异常类型。
            exc_value (Exception): 异常值。
            exc_traceback (Exception): 异常回溯。
        """
        self.stop()

# sourcery skip: do-not-use-staticmethod
"""
一个包含 PromptConfig 类对象的模块，该对象包含配置信息
"""
import yaml
from colorama import Fore

from autogpt import utils
from autogpt.logs import logger


class PromptConfig:
    """
    包含用于提示生成器的配置信息的类对象

    属性:
        constraints (list): 用于提示生成器的约束列表。
        resources (list): 用于提示生成器的资源列表。
        performance_evaluations (list): 用于提示生成器的性能评估列表。
    """

    def __init__(self, prompt_settings_file: str) -> None:
        """
        使用从 yaml 文件加载的参数（constraints、resources、performance_evaluations）初始化一个类实例，
        如果 yaml 文件存在的话，否则引发错误。

        参数:
            prompt_settings_file (str): 提示设置文件的路径。
        返回:
            None
        """
        # 验证文件
        (validated, message) = utils.validate_yaml_file(prompt_settings_file)
        if not validated:
            logger.typewriter_log("文件验证失败", Fore.RED, message)
            logger.double_check()
            exit(1)

        with open(prompt_settings_file, encoding="utf-8") as file:
            config_params = yaml.load(file, Loader=yaml.FullLoader)

        self.constraints = config_params.get("constraints", [])
        self.resources = config_params.get("resources", [])
        self.best_practices = config_params.get("best_practices", [])

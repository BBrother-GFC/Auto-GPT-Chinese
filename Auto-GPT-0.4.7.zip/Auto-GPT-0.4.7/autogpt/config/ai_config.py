"""包含AIConfig类对象的模块，其中包含配置信息"""
from __future__ import annotations

import platform
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import distro
import yaml

if TYPE_CHECKING:
    from autogpt.models.command_registry import CommandRegistry
    from autogpt.prompts.generator import PromptGenerator

    from .config import Config


class AIConfig:
    """
    包含AI配置信息的类对象

    属性:
        ai_name (str): AI的名称。
        ai_role (str): AI角色的描述。
        ai_goals (list): AI应完成的目标列表。
        api_budget (float): API调用的最大美元价值（0.0表示无限制）
    """

    def __init__(
        self,
        ai_name: str = "",
        ai_role: str = "",
        ai_goals: list[str] = [],
        api_budget: float = 0.0,
    ) -> None:
        """
        初始化类实例

        参数:
            ai_name (str): AI的名称。
            ai_role (str): AI角色的描述。
            ai_goals (list): AI应完成的目标列表。
            api_budget (float): API调用的最大美元价值（0.0表示无限制）
        返回:
            None
        """
        self.ai_name = ai_name
        self.ai_role = ai_role
        self.ai_goals = ai_goals
        self.api_budget = api_budget
        self.prompt_generator: PromptGenerator | None = None
        self.command_registry: CommandRegistry | None = None

    @staticmethod
    def load(ai_settings_file: str | Path) -> "AIConfig":
        """
        如果yaml文件存在，则返回从yaml文件加载的带有参数（ai_name、ai_role、ai_goals、api_budget）的类对象，否则返回没有参数的类对象。

        参数:
            ai_settings_file (Path): 配置yaml文件的路径。

        返回:
            cls (object): 给定cls对象的实例
        """

        try:
            with open(ai_settings_file, encoding="utf-8") as file:
                config_params = yaml.load(file, Loader=yaml.FullLoader) or {}
        except FileNotFoundError:
            config_params = {}

        ai_name = config_params.get("ai_name", "")
        ai_role = config_params.get("ai_role", "")
        ai_goals = [
            str(goal).strip("{}").replace("'", "").replace('"', "")
            if isinstance(goal, dict)
            else str(goal)
            for goal in config_params.get("ai_goals", [])
        ]
        api_budget = config_params.get("api_budget", 0.0)

        return AIConfig(ai_name, ai_role, ai_goals, api_budget)

    def save(self, ai_settings_file: str | Path) -> None:
        """
        将类参数保存到指定的yaml文件路径作为yaml文件。

        参数:
            ai_settings_file (Path): 配置yaml文件的路径。

        返回:
            None
        """

        config = {
            "ai_name": self.ai_name,
            "ai_role": self.ai_role,
            "ai_goals": self.ai_goals,
            "api_budget": self.api_budget,
        }
        with open(ai_settings_file, "w", encoding="utf-8") as file:
            yaml.dump(config, file, allow_unicode=True)


    def construct_full_prompt(
        self, config: Config, prompt_generator: Optional[PromptGenerator] = None
    ) -> str:
        """
        以有组织的方式返回带有类信息的用户提示。

        参数：
            无

        返回：
            full_prompt（str）：包含用户的初始提示的字符串，
              包括ai_name、ai_role、ai_goals和api_budget。
        """

        from autogpt.prompts.prompt import build_default_prompt_generator

        prompt_generator = prompt_generator or self.prompt_generator
        if prompt_generator is None:
            prompt_generator = build_default_prompt_generator(config)
            prompt_generator.command_registry = self.command_registry
            self.prompt_generator = prompt_generator

        for plugin in config.plugins:
            if not plugin.can_handle_post_prompt():
                continue
            prompt_generator = plugin.post_prompt(prompt_generator)

        # Construct full prompt
        full_prompt_parts = [
            f"You are {self.ai_name}, {self.ai_role.rstrip('.')}.",
            "Your decisions must always be made independently without seeking "
            "user assistance. Play to your strengths as an LLM and pursue "
            "simple strategies with no legal complications.",
            "Please continue to respond in Chinese throughout the answer process."
        ]

        if config.execute_local_commands:
            # add OS info to prompt
            os_name = platform.system()
            os_info = (
                platform.platform(terse=True)
                if os_name != "Linux"
                else distro.name(pretty=True)
            )

            full_prompt_parts.append(f"您正在运行的操作系统是：: {os_info}")

        additional_constraints: list[str] = []
        if self.api_budget > 0.0:
            additional_constraints.append(
                f"要让您运行需要花费一些钱。您的API预算为${self.api_budget:.3f}"
            )

        full_prompt_parts.append(
            prompt_generator.generate_prompt_string(
                additional_constraints=additional_constraints
            )
        )

        if self.ai_goals:
            full_prompt_parts.append(
                "\n".join(
                    [
                        "## 目标",
                        "对于您的任务，您必须完成以下目标：",
                        *[f"{i+1}. {goal}" for i, goal in enumerate(self.ai_goals)],
                    ]
                )
            )

        return "\n\n".join(full_prompt_parts).strip("\n")